# KeiroGenesis - Corrected Identity & Authorization Architecture

**Version**: 2.0 (Production Grade)  
**Date**: December 17, 2025  
**Status**: Architecturally Correct, MVP-Ready

---

## 🎯 Executive Summary

This is the **corrected, production-grade architecture** that properly separates:

1. **Identity Verification** - "Can we trust this human?" (SIGNALS)
2. **Authorization** - "Can they do X?" (DECISIONS based on capabilities assigned to roles)

### What Was Wrong Before

❌ **Identity module made authorization decisions**  
❌ **Feature gating hardcoded in identity service**  
❌ **No clear separation of concerns**  
❌ **Identity acting as gatekeeper instead of signal provider**

### What's Correct Now

✅ **Identity module returns trust signals only**  
✅ **Authorization service makes access decisions**  
✅ **Capability-based access control (CBAC)**  
✅ **Roles mapped to capabilities**  
✅ **Clear domain boundaries**

---

## 📁 What You Received

### 1. **IdentityVerification_Corrected.cs**
**Purpose**: Trust signal provider

**Responsibilities**:
- Verify user age
- Track verification attempts
- Record consent (GDPR/CCPA)
- Return verification level as SIGNAL
- **NOT** make authorization decisions

**Key Methods**:
```csharp
GetIdentityStatusAsync()      // Returns verification level (SIGNAL)
VerifyAgeAsync()               // MVP: Simple age verification
GetVerificationHistoryAsync()  // Audit trail
RecordConsentAsync()           // GDPR compliance
```

**V2/V3 Features (Disabled for MVP)**:
- `VerifyHumanAsync()` - Liveness check (returns 501)
- `VerifyGovernmentIDAsync()` - ID verification (returns 501)

### 2. **AuthorizationService.cs**
**Purpose**: Access decision maker

**Responsibilities**:
- Check if user has capability
- Combine signals: Identity + Role + Billing + Tenant Policy
- Make final access decision
- Manage role-capability assignments

**Key Methods**:
```csharp
CheckAccessAsync(capability)           // Makes access decision
GetUserCapabilitiesAsync()             // Gets all user capabilities
GetAuthorizationContextAsync()         // Complete authorization context
AssignCapabilityToRoleAsync()          // Admin: Assign capability to role
```

**Decision Factors**:
1. Identity verification level (SIGNAL from Identity module)
2. User roles
3. Capabilities assigned to roles
4. Subscription tier
5. Tenant policies

### 3. **authorization_schema.sql**
**Purpose**: Database schema for RBAC

**Tables**:
- `auth.roles` - User roles (User, Admin, SuperAdmin)
- `auth.capabilities` - System capabilities
- `auth.role_capabilities` - Maps capabilities to roles
- `auth.user_roles` - Assigns roles to users

**Stored Procedures**:
- `get_user_capabilities()` - Get capabilities via roles
- `user_has_capability()` - Check specific capability
- `assign_capability_to_role()` - Admin function
- `initialize_tenant_roles()` - Seed roles for new tenant

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    USER REQUEST                          │
│            "Can I enable monetization?"                  │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│           AUTHORIZATION SERVICE (DECISION)               │
│  "Can this user do X?" → YES/NO                         │
├─────────────────────────────────────────────────────────┤
│  Checks:                                                 │
│  1. Identity Level ← SIGNAL from Identity Module        │
│  2. User Roles                                           │
│  3. Capabilities (via Roles)                             │
│  4. Subscription Tier                                    │
│  5. Tenant Policy                                        │
└────────────────────┬────────────────────────────────────┘
                     │
            ┌────────┴────────┐
            ▼                 ▼
┌──────────────────┐  ┌──────────────────┐
│ IDENTITY MODULE  │  │  ROLE/CAPABILITY │
│    (SIGNAL)      │  │     SYSTEM       │
├──────────────────┤  ├──────────────────┤
│ Level: GovVerif  │  │ Role: User       │
│ Verified: Yes    │  │ Capabilities:    │
│ Expired: No      │  │ - clone.create   │
│                  │  │ - social.post    │
│ Returns: Trust   │  │                  │
│ Signal ONLY      │  │ Maps roles →     │
│                  │  │ capabilities     │
└──────────────────┘  └──────────────────┘
```

---

## 🔑 Key Concepts

### Identity Verification Levels (SIGNALS)

```csharp
public enum IdentityVerificationLevel
{
    Unverified = 0,        // Email/password only
    AgeAssured = 1,        // Age verified (18+ / minor)
    HumanVerified = 2,     // Liveness check passed
    GovernmentVerified = 3 // Government ID verified
}
```

**These are SIGNALS, not DECISIONS.**

### Capabilities (What Users Can Do)

Examples:
```
clone.create                    // Create clones
clone.public_visibility         // Make clones public
social.post                     // Create social posts
monetization.enable             // Enable monetization
monetization.payouts            // Receive payouts
iot.device_control              // Control IoT devices
family.invitations              // Invite family members
admin.users.manage              // Manage users (admin)
superadmin.tenants.manage       // Manage tenants (superadmin)
```

### Capability Requirements

Each capability has requirements:

```csharp
new CapabilityRequirements 
{ 
    MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified,
    MinTier = SubscriptionTier.Professional,
    RequiresRole = null // Or specific role like "Admin"
}
```

### Roles → Capabilities Mapping

**User Role** (Default):
- `clone.create`
- `clone.private_chat`
- `clone.delete`
- `social.message`

**Admin Role**:
- All User capabilities +
- `admin.users.manage`
- `admin.moderation`
- `admin.analytics`

**SuperAdmin Role**:
- All Admin capabilities +
- `superadmin.tenants.manage`
- `superadmin.system.config`

---

## 🚀 Integration Guide

### Step 1: Database Setup

```bash
# Run identity verification schema (from previous delivery)
psql -U postgres -d keiroogenesis_db -f identity_verification_schema.sql

# Run authorization schema
psql -U postgres -d keiroogenesis_db -f authorization_schema.sql
```

### Step 2: Register Services (DI)

```csharp
// In Program.cs or Startup.cs

// Identity Verification (signals only)
builder.Services.AddScoped<IdentityVerificationRepository>();
builder.Services.AddScoped<IdentityVerificationService>();

// Authorization (decisions)
builder.Services.AddScoped<AuthorizationRepository>();
builder.Services.AddScoped<AuthorizationService>();

// Controllers
builder.Services.AddControllers();
```

### Step 3: Initialize Tenant Roles

```csharp
// After creating a new tenant
public async Task<Tenant> CreateTenantAsync(CreateTenantRequest request)
{
    // Create tenant
    var tenant = await _tenantRepository.CreateAsync(request);
    
    // Initialize system roles and capabilities for this tenant
    await _dbConnection.ExecuteAsync(
        "SELECT auth.initialize_tenant_roles(@tenantId)",
        new { tenantId = tenant.Id });
    
    return tenant;
}
```

### Step 4: Assign User Role on Registration

```csharp
// After creating a new user
public async Task<User> RegisterUserAsync(RegisterRequest request)
{
    // Create user
    var user = await _userRepository.CreateAsync(request);
    
    // Initialize identity profile
    await _identityService.InitializeIdentityProfileAsync(user.TenantId, user.Id);
    
    // Assign default "User" role
    await _dbConnection.ExecuteAsync(
        "SELECT auth.assign_role_to_user(@tenantId, @userId, @role)",
        new { tenantId = user.TenantId, userId = user.Id, role = "User" });
    
    return user;
}
```

### Step 5: Check Access in Your Code

```csharp
// Example: Check if user can enable monetization
public async Task<IActionResult> EnableMonetization()
{
    var tenantId = GetTenantId();
    var userId = GetUserId();
    
    // Check access
    var decision = await _authorizationService.CheckAccessAsync(
        tenantId, userId, "monetization.enable");
    
    if (!decision.Allowed)
    {
        return Forbidden(new 
        { 
            message = decision.Reason,
            denialReasons = decision.DenialReasons,
            requiredIdentityLevel = decision.RequiredIdentityLevel,
            requiredTier = decision.RequiredTier
        });
    }
    
    // Proceed with monetization enablement
    await _monetizationService.EnableAsync(tenantId, userId);
    return Ok();
}
```

### Step 6: Update JWT Claims

```csharp
private async Task<string> GenerateJwtTokenAsync(User user)
{
    // Get identity status (SIGNAL)
    var identityStatus = await _identityService.GetIdentityStatusAsync(
        user.TenantId, user.Id);
    
    // Get user roles
    var roles = await _authorizationRepository.GetUserRolesAsync(
        user.TenantId, user.Id);
    
    var claims = new List<Claim>
    {
        new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
        new Claim("tenant_id", user.TenantId.ToString()),
        new Claim("email", user.Email),
        
        // Identity signals (for UI hints, NOT authorization)
        new Claim("identity_level", ((int)identityStatus.VerificationLevel).ToString()),
        new Claim("identity_verified", identityStatus.AgeVerified.ToString().ToLower())
    };
    
    // Add roles
    foreach (var role in roles)
    {
        claims.Add(new Claim(ClaimTypes.Role, role));
    }
    
    // Generate token...
}
```

---

## 📊 Example Access Decision Flow

### Scenario: User wants to enable monetization

**User**: Alice  
**Identity Level**: HumanVerified  
**Role**: User  
**Subscription**: Starter  

**Request**: Enable monetization

```
1. Authorization Service receives request
   ↓
2. Gets authorization context:
   - Identity Level: HumanVerified (SIGNAL from Identity module)
   - Roles: [User]
   - Capabilities: [clone.create, clone.private_chat, social.message]
   - Subscription Tier: Starter
   ↓
3. Checks capability requirements for "monetization.enable":
   - Required Identity: GovernmentVerified ❌ (Alice has HumanVerified)
   - Required Tier: Professional ❌ (Alice has Starter)
   - Required Role: None ✓
   ↓
4. Decision: DENIED
   Reasons:
   - "Requires GovernmentVerified identity (current: HumanVerified)"
   - "Requires Professional subscription (current: Starter)"
```

**Response to User**:
```json
{
  "allowed": false,
  "reason": "Access denied",
  "denialReasons": [
    "Requires GovernmentVerified identity verification (current: HumanVerified)",
    "Requires Professional subscription (current: Starter)"
  ],
  "requiredIdentityLevel": "GovernmentVerified",
  "currentIdentityLevel": "HumanVerified",
  "requiredTier": "Professional",
  "currentTier": "Starter"
}
```

---

## 🔐 Security Boundaries

### Identity Module
**Asks**: "Can we trust this human?"  
**Returns**: Verification level, timestamps, signals  
**Does NOT**: Make authorization decisions

### Authorization Service
**Asks**: "Can this user do X?"  
**Considers**: Identity signals + Roles + Capabilities + Billing + Tenant Policy  
**Returns**: Access decision (Allow/Deny)

### Clear Separation
```
Identity Module → Returns SIGNALS
Authorization Service → Makes DECISIONS using signals
```

---

## 📈 Capability Management (Admin)

### Assign Capability to Role

```csharp
// Admin wants to give "clone.public_visibility" to "User" role
await _authorizationService.AssignCapabilityToRoleAsync(
    tenantId, "User", "clone.public_visibility");
```

### Revoke Capability from Role

```csharp
// Admin wants to remove "social.post" from "User" role
await _authorizationService.RevokeCapabilityFromRoleAsync(
    tenantId, "User", "social.post");
```

### Assign Role to User

```csharp
// Promote user to Admin
await ExecuteAsync(
    "SELECT auth.assign_role_to_user(@tenantId, @userId, @role)",
    new { tenantId, userId, role = "Admin" });
```

---

## 🎯 MVP vs V2/V3 Features

### MVP (Available Now)
✅ Identity status tracking  
✅ Simple age verification  
✅ Consent recording  
✅ Role-based access control  
✅ Capability-based authorization  
✅ Subscription tier gating  

### V2 (Feature Flagged)
🔒 Human verification (liveness check)  
🔒 Webhook processing from providers  
🔒 Advanced age estimation  

### V3 (Future)
🔒 Government ID verification  
🔒 Third-party KYC integration (Jumio, IDMERIT)  
🔒 Admin review queues  
🔒 Fraud detection  

**Enable via configuration**:
```json
{
  "Features": {
    "HumanVerification": false,      // V2
    "GovernmentIDVerification": false // V3
  }
}
```

---

## ⚠️ Critical Architectural Rules

### Rule 1: Identity Never Decides Access
```csharp
// ❌ WRONG - Identity making authorization decision
if (identityLevel == IdentityVerificationLevel.GovernmentVerified)
{
    EnableMonetization();
}

// ✅ CORRECT - Authorization service decides
var decision = await _authorizationService.CheckAccessAsync(
    tenantId, userId, "monetization.enable");
if (decision.Allowed)
{
    EnableMonetization();
}
```

### Rule 2: JWT Claims Are Hints, Not Authority
```csharp
// ❌ WRONG - Trusting JWT claim for authorization
if (User.FindFirst("identity_level")?.Value == "3")
{
    // Allow action
}

// ✅ CORRECT - Always check via Authorization service
var decision = await _authorizationService.CheckAccessAsync(...);
```

### Rule 3: One Identity Profile Per User
```csharp
// Enforced by DB constraint:
CONSTRAINT unique_user_identity_profile UNIQUE (tenant_id, user_id)
```

### Rule 4: Capabilities Are Assigned to Roles, Not Users Directly
```csharp
// ❌ WRONG - No direct user-capability assignment

// ✅ CORRECT - User → Role → Capabilities
User has Role(s) → Role has Capability(ies) → User has Capability(ies)
```

---

## 🧪 Testing

### Test Identity Verification

```csharp
[Fact]
public async Task VerifyAge_ShouldUpdateIdentityLevel()
{
    // Arrange
    var user = await CreateTestUser();
    var request = new AgeVerificationRequest 
    { 
        ConsentGiven = true, 
        PolicyVersion = "1.0" 
    };
    
    // Act
    var result = await _identityService.VerifyAgeAsync(
        user.TenantId, user.Id, request);
    
    // Assert
    Assert.True(result.Success);
    Assert.Equal(AgeVerificationResult.Adult, result.AgeCategory);
    
    var status = await _identityService.GetIdentityStatusAsync(
        user.TenantId, user.Id);
    Assert.Equal(IdentityVerificationLevel.AgeAssured, status.VerificationLevel);
}
```

### Test Authorization

```csharp
[Fact]
public async Task CheckAccess_WithInsufficientIdentity_ShouldDeny()
{
    // Arrange
    var user = await CreateTestUser();
    // User has Unverified identity, needs GovernmentVerified for monetization
    
    // Act
    var decision = await _authorizationService.CheckAccessAsync(
        user.TenantId, user.Id, "monetization.enable");
    
    // Assert
    Assert.False(decision.Allowed);
    Assert.Contains("Requires GovernmentVerified", decision.DenialReasons);
}
```

---

## 📚 Database Queries

### Check User's Capabilities

```sql
SELECT * FROM auth.get_user_capabilities('tenant-id', 'user-id');
```

### Check If User Has Specific Capability

```sql
SELECT auth.user_has_capability('tenant-id', 'user-id', 'clone.create');
```

### Get User's Identity Level

```sql
SELECT * FROM auth.get_identity_verification_level('tenant-id', 'user-id');
```

### Assign Capability to Role

```sql
SELECT auth.assign_capability_to_role('tenant-id', 'User', 'clone.public_visibility');
```

---

## 🎓 Summary

### What Changed from Previous Version

**Before** (Incorrect):
- Identity module made feature gating decisions
- Hardcoded feature requirements
- Tight coupling between identity and authorization
- No role/capability system

**Now** (Correct):
- Identity module returns trust signals only
- Authorization service makes access decisions
- Capability-based access control (CBAC)
- Roles mapped to capabilities
- Clean separation of concerns

### Why This Matters

1. **Scalability**: Can add new capabilities without touching identity code
2. **Flexibility**: Tenant-specific capability assignments
3. **Clarity**: Clear domain boundaries
4. **Testability**: Each service has single responsibility
5. **Compliance**: Proper separation for audit trails

### Production Readiness

✅ **MVP-Ready**: Core features work without v2/v3 complexity  
✅ **Architecturally Sound**: Proper domain separation  
✅ **Future-Proof**: V2/V3 features disabled but ready  
✅ **Enterprise-Grade**: RBAC + CBAC + multi-tenant isolation  

---

**You now have a production-grade, architecturally correct Identity & Authorization system.** 🎉
