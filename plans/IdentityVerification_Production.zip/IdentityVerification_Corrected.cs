using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Npgsql;
using System.Data;
using System.Security.Claims;
using System.Text.Json;

namespace KeiroGenesis.Identity
{
    // =========================================================================
    // IDENTITY VERIFICATION - TRUST SIGNALS ONLY
    // Purpose: Answer "Can we trust this human?"
    // NOT: "Can they do X?" (that's Authorization service)
    // =========================================================================
    
    // =========================================================================
    // CONTROLLER - Identity Verification Endpoints
    // =========================================================================
    
    [ApiController]
    [Route("api/v1/auth/identity")]
    [Produces("application/json")]
    public class IdentityVerificationController : ControllerBase
    {
        private readonly IdentityVerificationService _service;
        private readonly ILogger<IdentityVerificationController> _logger;

        public IdentityVerificationController(
            IdentityVerificationService service,
            ILogger<IdentityVerificationController> logger)
        {
            _service = service;
            _logger = logger;
        }

        private Guid GetTenantId() => Guid.Parse(User.FindFirst("tenant_id")?.Value 
            ?? throw new UnauthorizedAccessException("Tenant ID not found"));
        private Guid GetUserId() => Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value 
            ?? throw new UnauthorizedAccessException("User ID not found"));

        /// <summary>
        /// Gets identity verification status (SIGNAL only - not authorization).
        /// Returns verification level, timestamps, and trust signals.
        /// </summary>
        [HttpGet("status")]
        [Authorize]
        public async Task<ActionResult<IdentityStatusResponse>> GetStatus()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.GetIdentityStatusAsync(tenantId, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting identity status");
                return StatusCode(500, new { message = "Failed to retrieve identity status" });
            }
        }

        /// <summary>
        /// Initializes identity profile for new user.
        /// Called during registration flow.
        /// </summary>
        [HttpPost("initialize")]
        [Authorize]
        public async Task<ActionResult<IdentityStatusResponse>> Initialize()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.InitializeIdentityProfileAsync(tenantId, userId);
                return CreatedAtAction(nameof(GetStatus), result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initializing identity profile");
                return StatusCode(500, new { message = "Failed to initialize identity profile" });
            }
        }

        /// <summary>
        /// Initiates age verification (MVP: Simple flow).
        /// </summary>
        [HttpPost("age-verify")]
        [Authorize]
        public async Task<ActionResult<AgeVerificationResponse>> VerifyAge([FromBody] AgeVerificationRequest request)
        {
            try
            {
                if (!request.ConsentGiven)
                    return BadRequest(new { message = "User consent required for age verification" });

                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.VerifyAgeAsync(tenantId, userId, request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error verifying age");
                return StatusCode(500, new { message = "Failed to verify age" });
            }
        }

        /// <summary>
        /// Gets verification attempt history for audit purposes.
        /// </summary>
        [HttpGet("history")]
        [Authorize]
        public async Task<ActionResult<List<VerificationAttemptResponse>>> GetHistory()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.GetVerificationHistoryAsync(tenantId, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving verification history");
                return StatusCode(500, new { message = "Failed to retrieve verification history" });
            }
        }

        /// <summary>
        /// Records user consent for identity processing (GDPR/CCPA).
        /// </summary>
        [HttpPost("consent")]
        [Authorize]
        public async Task<ActionResult<ConsentResponse>> RecordConsent([FromBody] ConsentRequest request)
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.RecordConsentAsync(tenantId, userId, request);
                return CreatedAtAction(nameof(GetConsentRecords), result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error recording consent");
                return StatusCode(500, new { message = "Failed to record consent" });
            }
        }

        /// <summary>
        /// Gets all consent records for compliance audit.
        /// </summary>
        [HttpGet("consent")]
        [Authorize]
        public async Task<ActionResult<List<ConsentResponse>>> GetConsentRecords()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.GetConsentRecordsAsync(tenantId, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving consent records");
                return StatusCode(500, new { message = "Failed to retrieve consent records" });
            }
        }

        // =====================================================================
        // V2+ ENDPOINTS - Disabled for MVP, enabled via feature flags
        // =====================================================================

        /// <summary>
        /// [V2] Initiates human verification (liveness check).
        /// Disabled for MVP - returns 501 Not Implemented.
        /// </summary>
        [HttpPost("human-verify")]
        [Authorize]
        public async Task<ActionResult> VerifyHuman([FromBody] HumanVerificationRequest request)
        {
            // Feature flag check
            if (!_service.IsHumanVerificationEnabled())
            {
                return StatusCode(501, new { message = "Human verification not available in current plan" });
            }

            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.VerifyHumanAsync(tenantId, userId, request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initiating human verification");
                return StatusCode(500, new { message = "Failed to initiate human verification" });
            }
        }

        /// <summary>
        /// [V3] Initiates government ID verification.
        /// Disabled for MVP - returns 501 Not Implemented.
        /// </summary>
        [HttpPost("id-verify")]
        [Authorize]
        public async Task<ActionResult> VerifyGovernmentID([FromBody] GovernmentIDVerificationRequest request)
        {
            // Feature flag check
            if (!_service.IsGovernmentIDVerificationEnabled())
            {
                return StatusCode(501, new { message = "Government ID verification not available in current plan" });
            }

            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.VerifyGovernmentIDAsync(tenantId, userId, request);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error initiating government ID verification");
                return StatusCode(500, new { message = "Failed to initiate government ID verification" });
            }
        }
    }

    // =========================================================================
    // SERVICE - Identity Verification Business Logic
    // =========================================================================
    
    public class IdentityVerificationService
    {
        private readonly IdentityVerificationRepository _repository;
        private readonly ILogger<IdentityVerificationService> _logger;
        private readonly IConfiguration _config;

        public IdentityVerificationService(
            IdentityVerificationRepository repository,
            ILogger<IdentityVerificationService> logger,
            IConfiguration config)
        {
            _repository = repository;
            _logger = logger;
            _config = config;
        }

        // Feature flags for v2/v3 features
        public bool IsHumanVerificationEnabled() => 
            _config.GetValue<bool>("Features:HumanVerification", false);
        
        public bool IsGovernmentIDVerificationEnabled() => 
            _config.GetValue<bool>("Features:GovernmentIDVerification", false);

        /// <summary>
        /// Gets identity verification status.
        /// Returns SIGNALS only - does NOT make authorization decisions.
        /// </summary>
        public async Task<IdentityStatusResponse> GetIdentityStatusAsync(Guid tenantId, Guid userId)
        {
            var profile = await _repository.GetIdentityProfileByUserIdAsync(tenantId, userId);
            
            if (profile == null)
            {
                return new IdentityStatusResponse
                {
                    UserId = userId,
                    VerificationLevel = IdentityVerificationLevel.Unverified,
                    AgeVerified = false,
                    AgeCategory = AgeVerificationResult.Unknown,
                    HumanVerified = false,
                    GovernmentIDVerified = false,
                    IsExpired = false,
                    RequiresReverification = false
                };
            }

            // Check expiration
            var isExpired = profile.ExpiresAt.HasValue && profile.ExpiresAt.Value < DateTime.UtcNow;

            return new IdentityStatusResponse
            {
                UserId = userId,
                VerificationLevel = profile.VerificationLevel,
                AgeVerified = profile.AgeVerified,
                AgeCategory = profile.AgeCategory,
                HumanVerified = profile.HumanVerified,
                GovernmentIDVerified = profile.GovernmentIDVerified,
                VerifiedAt = profile.VerifiedAt,
                ExpiresAt = profile.ExpiresAt,
                IsExpired = isExpired,
                RequiresReverification = profile.RequiresReverification || isExpired,
                ReverificationReason = profile.ReverificationReason
            };
        }

        /// <summary>
        /// Initializes identity profile for new user.
        /// Creates profile with Unverified status.
        /// </summary>
        public async Task<IdentityStatusResponse> InitializeIdentityProfileAsync(Guid tenantId, Guid userId)
        {
            var existing = await _repository.GetIdentityProfileByUserIdAsync(tenantId, userId);
            if (existing != null)
            {
                _logger.LogWarning("Identity profile already exists for user {UserId}", userId);
                return await GetIdentityStatusAsync(tenantId, userId);
            }

            await _repository.CreateIdentityProfileAsync(tenantId, userId);
            _logger.LogInformation("Initialized identity profile for user {UserId} in tenant {TenantId}", userId, tenantId);

            return await GetIdentityStatusAsync(tenantId, userId);
        }

        /// <summary>
        /// MVP: Simple age verification flow.
        /// Records consent and creates verification attempt.
        /// </summary>
        public async Task<AgeVerificationResponse> VerifyAgeAsync(
            Guid tenantId,
            Guid userId,
            AgeVerificationRequest request)
        {
            var profile = await _repository.GetIdentityProfileByUserIdAsync(tenantId, userId);
            if (profile == null)
            {
                await InitializeIdentityProfileAsync(tenantId, userId);
                profile = await _repository.GetIdentityProfileByUserIdAsync(tenantId, userId);
            }

            // Record consent
            await RecordConsentAsync(tenantId, userId, new ConsentRequest
            {
                ConsentType = ConsentType.AgeVerification,
                Granted = true,
                PolicyVersion = request.PolicyVersion,
                ConsentText = "User consents to age verification processing"
            });

            // Create verification attempt
            var attemptId = await _repository.CreateVerificationAttemptAsync(
                tenantId, profile!.Id, userId, VerificationMethod.AIAgeEstimation,
                VerificationStatus.InProgress, null, null, null, null);

            // MVP: Simple age estimation (placeholder - implement actual logic)
            var ageCategory = DetermineAgeCategory(request);
            var confidenceScore = 85.0m; // Placeholder

            // Complete verification
            var status = ageCategory == AgeVerificationResult.Inconclusive 
                ? VerificationStatus.Failed 
                : VerificationStatus.Verified;

            await _repository.UpdateVerificationAttemptStatusAsync(
                tenantId, attemptId, status,
                JsonSerializer.Serialize(new { ageCategory, confidenceScore }),
                null, confidenceScore, false, null, DateTime.UtcNow, 0, 0);

            // Update profile if successful
            if (status == VerificationStatus.Verified)
            {
                await _repository.UpdateVerificationLevelAsync(
                    tenantId, userId, IdentityVerificationLevel.AgeAssured,
                    true, ageCategory, false, false);

                _logger.LogInformation(
                    "User {UserId} age verified as {Category} in tenant {TenantId}", 
                    userId, ageCategory, tenantId);
            }

            return new AgeVerificationResponse
            {
                AttemptId = attemptId,
                Status = status,
                AgeCategory = ageCategory,
                Success = status == VerificationStatus.Verified,
                Message = GetAgeVerificationMessage(ageCategory),
                ConfidenceScore = confidenceScore,
                CompletedAt = DateTime.UtcNow
            };
        }

        /// <summary>
        /// [V2] Human verification (liveness check).
        /// Stubbed for MVP - implement when needed.
        /// </summary>
        public async Task<HumanVerificationResponse> VerifyHumanAsync(
            Guid tenantId,
            Guid userId,
            HumanVerificationRequest request)
        {
            throw new NotImplementedException("Human verification available in v2");
        }

        /// <summary>
        /// [V3] Government ID verification.
        /// Stubbed for MVP - implement when needed.
        /// </summary>
        public async Task<GovernmentIDVerificationResponse> VerifyGovernmentIDAsync(
            Guid tenantId,
            Guid userId,
            GovernmentIDVerificationRequest request)
        {
            throw new NotImplementedException("Government ID verification available in v3");
        }

        /// <summary>
        /// Gets verification attempt history for audit.
        /// </summary>
        public async Task<List<VerificationAttemptResponse>> GetVerificationHistoryAsync(
            Guid tenantId,
            Guid userId)
        {
            var attempts = await _repository.GetVerificationAttemptsByUserIdAsync(tenantId, userId, 10);
            return attempts.Select(a => new VerificationAttemptResponse
            {
                Id = a.Id,
                Method = a.Method,
                Status = a.Status,
                Provider = a.Provider,
                ConfidenceScore = a.ConfidenceScore,
                FraudAlertTriggered = a.FraudAlertTriggered,
                InitiatedAt = a.InitiatedAt,
                CompletedAt = a.CompletedAt,
                FailureReason = a.FailureReason
            }).ToList();
        }

        /// <summary>
        /// Records user consent (GDPR/CCPA compliance).
        /// </summary>
        public async Task<ConsentResponse> RecordConsentAsync(
            Guid tenantId,
            Guid userId,
            ConsentRequest request)
        {
            var profile = await _repository.GetIdentityProfileByUserIdAsync(tenantId, userId);
            if (profile == null)
            {
                throw new InvalidOperationException("Identity profile not found");
            }

            var consentId = await _repository.CreateConsentRecordAsync(
                tenantId, profile.Id, userId, request.ConsentType, request.Granted,
                request.PolicyVersion, request.ConsentText, null, null, null);

            _logger.LogInformation(
                "Consent recorded for user {UserId}: {ConsentType} = {Granted}", 
                userId, request.ConsentType, request.Granted);

            return new ConsentResponse
            {
                Id = consentId,
                ConsentType = request.ConsentType,
                Granted = request.Granted,
                PolicyVersion = request.PolicyVersion,
                ConsentedAt = DateTime.UtcNow,
                Revoked = false
            };
        }

        /// <summary>
        /// Gets all consent records for compliance audit.
        /// </summary>
        public async Task<List<ConsentResponse>> GetConsentRecordsAsync(Guid tenantId, Guid userId)
        {
            var consents = await _repository.GetConsentRecordsByUserIdAsync(tenantId, userId);
            return consents.Select(c => new ConsentResponse
            {
                Id = c.Id,
                ConsentType = c.ConsentType,
                Granted = c.Granted,
                PolicyVersion = c.PolicyVersion,
                ConsentedAt = c.ConsentedAt,
                ExpiresAt = c.ExpiresAt,
                Revoked = c.Revoked,
                RevokedAt = c.RevokedAt
            }).ToList();
        }

        // Helper methods
        private AgeVerificationResult DetermineAgeCategory(AgeVerificationRequest request)
        {
            // MVP: Simple placeholder logic
            // In production: Call actual age estimation service
            return AgeVerificationResult.Adult;
        }

        private string GetAgeVerificationMessage(AgeVerificationResult result)
        {
            return result switch
            {
                AgeVerificationResult.Adult => "Age verification successful - User is 18+",
                AgeVerificationResult.Minor => "Age verification complete - User is a minor",
                AgeVerificationResult.Inconclusive => "Age verification inconclusive - Please try again",
                _ => "Age verification status unknown"
            };
        }
    }

    // =========================================================================
    // REPOSITORY - Database Access Layer
    // =========================================================================
    
    public class IdentityVerificationRepository
    {
        private readonly string _connectionString;

        public IdentityVerificationRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("KeiroGenesisDb") 
                ?? throw new ArgumentNullException("Database connection string not found");
        }

        private IDbConnection CreateConnection() => new NpgsqlConnection(_connectionString);

        public async Task<IdentityProfile?> GetIdentityProfileByUserIdAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<IdentityProfile>(
                "auth.get_identity_profile_by_user",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<IdentityProfile?> GetIdentityProfileByIdAsync(Guid tenantId, Guid profileId)
        {
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<IdentityProfile>(
                "auth.get_identity_profile_by_id",
                new { p_tenant_id = tenantId, p_profile_id = profileId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<Guid> CreateIdentityProfileAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            return await connection.QuerySingleAsync<Guid>(
                "auth.create_identity_profile",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> UpdateVerificationLevelAsync(
            Guid tenantId,
            Guid userId,
            IdentityVerificationLevel level,
            bool ageVerified,
            AgeVerificationResult ageCategory,
            bool humanVerified,
            bool governmentIDVerified)
        {
            using var connection = CreateConnection();
            var result = await connection.ExecuteAsync(
                "auth.update_verification_level",
                new
                {
                    p_tenant_id = tenantId,
                    p_user_id = userId,
                    p_verification_level = level,
                    p_age_verified = ageVerified,
                    p_age_category = ageCategory,
                    p_human_verified = humanVerified,
                    p_government_id_verified = governmentIDVerified
                },
                commandType: CommandType.StoredProcedure);
            return result > 0;
        }

        public async Task<Guid> CreateVerificationAttemptAsync(
            Guid tenantId,
            Guid identityProfileId,
            Guid userId,
            VerificationMethod method,
            VerificationStatus status,
            VerificationProvider? provider,
            string? providerTransactionId,
            string? ipAddress,
            string? userAgent)
        {
            using var connection = CreateConnection();
            return await connection.QuerySingleAsync<Guid>(
                "auth.create_verification_attempt",
                new
                {
                    p_tenant_id = tenantId,
                    p_identity_profile_id = identityProfileId,
                    p_user_id = userId,
                    p_method = method,
                    p_status = status,
                    p_provider = provider,
                    p_provider_transaction_id = providerTransactionId,
                    p_ip_address = ipAddress,
                    p_user_agent = userAgent
                },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> UpdateVerificationAttemptStatusAsync(
            Guid tenantId,
            Guid attemptId,
            VerificationStatus status,
            string? resultData,
            string? failureReason,
            decimal? confidenceScore,
            bool fraudAlertTriggered,
            string? fraudAlertDetails,
            DateTime? completedAt,
            int? processingDurationMs,
            int? costCents)
        {
            using var connection = CreateConnection();
            var result = await connection.ExecuteAsync(
                "auth.update_verification_attempt",
                new
                {
                    p_tenant_id = tenantId,
                    p_attempt_id = attemptId,
                    p_status = status,
                    p_result_data = resultData,
                    p_failure_reason = failureReason,
                    p_confidence_score = confidenceScore,
                    p_fraud_alert_triggered = fraudAlertTriggered,
                    p_fraud_alert_details = fraudAlertDetails,
                    p_completed_at = completedAt,
                    p_processing_duration_ms = processingDurationMs,
                    p_cost_cents = costCents
                },
                commandType: CommandType.StoredProcedure);
            return result > 0;
        }

        public async Task<VerificationAttempt?> GetVerificationAttemptByIdAsync(Guid tenantId, Guid attemptId)
        {
            using var connection = CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<VerificationAttempt>(
                "auth.get_verification_attempt_by_id",
                new { p_tenant_id = tenantId, p_attempt_id = attemptId },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<List<VerificationAttempt>> GetVerificationAttemptsByUserIdAsync(
            Guid tenantId,
            Guid userId,
            int limit)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryAsync<VerificationAttempt>(
                "auth.get_verification_attempts_by_user",
                new { p_tenant_id = tenantId, p_user_id = userId, p_limit = limit },
                commandType: CommandType.StoredProcedure);
            return result.ToList();
        }

        public async Task<Guid> CreateConsentRecordAsync(
            Guid tenantId,
            Guid identityProfileId,
            Guid userId,
            ConsentType consentType,
            bool granted,
            string policyVersion,
            string consentText,
            string? ipAddress,
            string? userAgent,
            DateTime? expiresAt)
        {
            using var connection = CreateConnection();
            return await connection.QuerySingleAsync<Guid>(
                "auth.create_consent_record",
                new
                {
                    p_tenant_id = tenantId,
                    p_identity_profile_id = identityProfileId,
                    p_user_id = userId,
                    p_consent_type = consentType,
                    p_granted = granted,
                    p_policy_version = policyVersion,
                    p_consent_text = consentText,
                    p_ip_address = ipAddress,
                    p_user_agent = userAgent,
                    p_expires_at = expiresAt
                },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<List<ConsentRecord>> GetConsentRecordsByUserIdAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryAsync<ConsentRecord>(
                "auth.get_consent_records_by_user",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);
            return result.ToList();
        }
    }
}

// =========================================================================
// DOMAIN MODELS
// =========================================================================

namespace KeiroGenesis.Identity.Models
{
    public class IdentityProfile
    {
        public Guid Id { get; set; }
        public Guid TenantId { get; set; }
        public Guid UserId { get; set; }
        public IdentityVerificationLevel VerificationLevel { get; set; }
        public bool AgeVerified { get; set; }
        public AgeVerificationResult AgeCategory { get; set; }
        public bool HumanVerified { get; set; }
        public bool GovernmentIDVerified { get; set; }
        public string? ProviderReference { get; set; }
        public VerificationProvider? Provider { get; set; }
        public DateTime? VerifiedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool RequiresReverification { get; set; }
        public string? ReverificationReason { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }

    public class VerificationAttempt
    {
        public Guid Id { get; set; }
        public Guid TenantId { get; set; }
        public Guid IdentityProfileId { get; set; }
        public Guid UserId { get; set; }
        public VerificationMethod Method { get; set; }
        public VerificationStatus Status { get; set; }
        public VerificationProvider? Provider { get; set; }
        public string? ProviderTransactionId { get; set; }
        public string? IpAddress { get; set; }
        public string? UserAgent { get; set; }
        public string? ResultData { get; set; }
        public string? FailureReason { get; set; }
        public decimal? ConfidenceScore { get; set; }
        public bool FraudAlertTriggered { get; set; }
        public string? FraudAlertDetails { get; set; }
        public DateTime InitiatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public int? ProcessingDurationMs { get; set; }
        public int? CostCents { get; set; }
    }

    public class ConsentRecord
    {
        public Guid Id { get; set; }
        public Guid TenantId { get; set; }
        public Guid IdentityProfileId { get; set; }
        public Guid UserId { get; set; }
        public ConsentType ConsentType { get; set; }
        public bool Granted { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public string ConsentText { get; set; } = string.Empty;
        public string? IpAddress { get; set; }
        public string? UserAgent { get; set; }
        public DateTime ConsentedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool Revoked { get; set; }
        public DateTime? RevokedAt { get; set; }
        public string? RevocationReason { get; set; }
    }
}

// =========================================================================
// DTOs
// =========================================================================

namespace KeiroGenesis.Identity.DTOs
{
    public class IdentityStatusResponse
    {
        public Guid UserId { get; set; }
        public IdentityVerificationLevel VerificationLevel { get; set; }
        public bool AgeVerified { get; set; }
        public AgeVerificationResult AgeCategory { get; set; }
        public bool HumanVerified { get; set; }
        public bool GovernmentIDVerified { get; set; }
        public DateTime? VerifiedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool IsExpired { get; set; }
        public bool RequiresReverification { get; set; }
        public string? ReverificationReason { get; set; }
    }

    public class AgeVerificationRequest
    {
        public VerificationMethod Method { get; set; }
        public bool ConsentGiven { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public Dictionary<string, string>? Metadata { get; set; }
    }

    public class AgeVerificationResponse
    {
        public Guid AttemptId { get; set; }
        public VerificationStatus Status { get; set; }
        public AgeVerificationResult AgeCategory { get; set; }
        public bool Success { get; set; }
        public string? Message { get; set; }
        public decimal? ConfidenceScore { get; set; }
        public DateTime CompletedAt { get; set; }
    }

    public class HumanVerificationRequest
    {
        public bool ConsentGiven { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public VerificationProvider? PreferredProvider { get; set; }
    }

    public class HumanVerificationResponse
    {
        public Guid AttemptId { get; set; }
        public string? SessionUrl { get; set; }
        public string? SessionToken { get; set; }
        public VerificationProvider Provider { get; set; }
        public int ExpiresInSeconds { get; set; }
        public string? Message { get; set; }
    }

    public class GovernmentIDVerificationRequest
    {
        public bool ConsentGiven { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public VerificationProvider? PreferredProvider { get; set; }
        public string? DocumentType { get; set; }
        public string? IssuingCountry { get; set; }
    }

    public class GovernmentIDVerificationResponse
    {
        public Guid AttemptId { get; set; }
        public string? SessionUrl { get; set; }
        public string? SessionToken { get; set; }
        public VerificationProvider Provider { get; set; }
        public int ExpiresInSeconds { get; set; }
        public string? Message { get; set; }
    }

    public class ConsentRequest
    {
        public ConsentType ConsentType { get; set; }
        public bool Granted { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public string ConsentText { get; set; } = string.Empty;
    }

    public class ConsentResponse
    {
        public Guid Id { get; set; }
        public ConsentType ConsentType { get; set; }
        public bool Granted { get; set; }
        public string PolicyVersion { get; set; } = string.Empty;
        public DateTime ConsentedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
        public bool Revoked { get; set; }
        public DateTime? RevokedAt { get; set; }
    }

    public class VerificationAttemptResponse
    {
        public Guid Id { get; set; }
        public VerificationMethod Method { get; set; }
        public VerificationStatus Status { get; set; }
        public VerificationProvider? Provider { get; set; }
        public decimal? ConfidenceScore { get; set; }
        public bool FraudAlertTriggered { get; set; }
        public DateTime InitiatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }
        public string? FailureReason { get; set; }
    }
}

// =========================================================================
// ENUMS
// =========================================================================

namespace KeiroGenesis.Identity
{
    public enum IdentityVerificationLevel
    {
        Unverified = 0,
        AgeAssured = 1,
        HumanVerified = 2,
        GovernmentVerified = 3
    }

    public enum VerificationMethod
    {
        None = 0,
        AIAgeEstimation = 1,
        ZeroKnowledgeAgeProof = 2,
        LivenessSelfie = 3,
        GovernmentID = 4,
        DigitalWalletID = 5,
        ThirdPartyKYC = 6
    }

    public enum VerificationStatus
    {
        Pending = 0,
        InProgress = 1,
        Verified = 2,
        Failed = 3,
        Expired = 4,
        ManuallyApproved = 5,
        ManuallyRejected = 6
    }

    public enum AgeVerificationResult
    {
        Unknown = 0,
        Minor = 1,
        Adult = 2,
        Inconclusive = 3
    }

    public enum ConsentType
    {
        AgeVerification = 1,
        BiometricProcessing = 2,
        GovernmentIDVerification = 3,
        ThirdPartySharing = 4,
        LongTermRetention = 5
    }

    public enum VerificationProvider
    {
        Internal = 0,
        Jumio = 1,
        IDMERIT = 2,
        Onfido = 3,
        Yoti = 4,
        StripeIdentity = 5,
        Custom = 99
    }
}
