-- =========================================================================
-- KeiroGenesis Authorization & Capability System - PostgreSQL Schema
-- Version: 2.0 (Corrected Architecture)
-- Date: December 17, 2025
-- Description: Role-based access control with capability assignments
-- =========================================================================

-- =========================================================================
-- SCHEMA CREATION
-- =========================================================================

CREATE SCHEMA IF NOT EXISTS auth;
SET search_path TO auth, public;

-- =========================================================================
-- TABLES - Roles & Capabilities
-- =========================================================================

-- -------------------------------------------------------------------------
-- Roles
-- -------------------------------------------------------------------------
CREATE TABLE auth.roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES auth.tenants(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    is_system_role BOOLEAN NOT NULL DEFAULT FALSE, -- System roles cannot be deleted
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT unique_tenant_role_name UNIQUE (tenant_id, name)
);

CREATE INDEX idx_roles_tenant ON auth.roles(tenant_id);
CREATE INDEX idx_roles_system ON auth.roles(is_system_role) WHERE is_system_role = TRUE;

COMMENT ON TABLE auth.roles IS 'User roles for RBAC (e.g., User, Admin, SuperAdmin)';

-- -------------------------------------------------------------------------
-- Capabilities
-- -------------------------------------------------------------------------
CREATE TABLE auth.capabilities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL UNIQUE, -- Global capability namespace
    description TEXT,
    category VARCHAR(50), -- e.g., 'clone', 'monetization', 'iot', 'admin'
    is_system_capability BOOLEAN NOT NULL DEFAULT TRUE, -- System capabilities cannot be deleted
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    CONSTRAINT check_capability_name CHECK (name ~ '^[a-z_]+\.[a-z_]+$') -- Format: category.action
);

CREATE INDEX idx_capabilities_category ON auth.capabilities(category);

COMMENT ON TABLE auth.capabilities IS 'System capabilities (e.g., clone.create, monetization.enable)';
COMMENT ON COLUMN auth.capabilities.name IS 'Capability name in format: category.action (e.g., clone.create)';

-- -------------------------------------------------------------------------
-- Role-Capability Assignments
-- -------------------------------------------------------------------------
CREATE TABLE auth.role_capabilities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES auth.tenants(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES auth.roles(id) ON DELETE CASCADE,
    capability_name VARCHAR(100) NOT NULL REFERENCES auth.capabilities(name) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by UUID, -- Admin who assigned this capability
    
    CONSTRAINT unique_role_capability UNIQUE (tenant_id, role_id, capability_name),
    CONSTRAINT fk_role_tenant FOREIGN KEY (tenant_id, role_id) REFERENCES auth.roles(tenant_id, id)
);

CREATE INDEX idx_role_capabilities_tenant_role ON auth.role_capabilities(tenant_id, role_id);
CREATE INDEX idx_role_capabilities_capability ON auth.role_capabilities(capability_name);

COMMENT ON TABLE auth.role_capabilities IS 'Maps capabilities to roles (e.g., Admin role has admin.users.manage capability)';

-- -------------------------------------------------------------------------
-- User-Role Assignments
-- -------------------------------------------------------------------------
CREATE TABLE auth.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES auth.tenants(id) ON DELETE CASCADE,
    user_id UUID NOT NULL,
    role_id UUID NOT NULL,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by UUID, -- Admin who assigned this role
    expires_at TIMESTAMPTZ, -- Optional: Temporary role assignments
    
    CONSTRAINT fk_user FOREIGN KEY (tenant_id, user_id) REFERENCES auth.users(tenant_id, id) ON DELETE CASCADE,
    CONSTRAINT fk_role FOREIGN KEY (tenant_id, role_id) REFERENCES auth.roles(tenant_id, id) ON DELETE CASCADE,
    CONSTRAINT unique_user_role UNIQUE (tenant_id, user_id, role_id)
);

CREATE INDEX idx_user_roles_tenant_user ON auth.user_roles(tenant_id, user_id);
CREATE INDEX idx_user_roles_role ON auth.user_roles(role_id);
CREATE INDEX idx_user_roles_expiration ON auth.user_roles(expires_at) WHERE expires_at IS NOT NULL;

COMMENT ON TABLE auth.user_roles IS 'Assigns roles to users';

-- =========================================================================
-- STORED PROCEDURES - Authorization Queries
-- =========================================================================

-- -------------------------------------------------------------------------
-- Get Identity Verification Level (SIGNAL from Identity module)
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.get_identity_verification_level(
    p_tenant_id UUID,
    p_user_id UUID
)
RETURNS TABLE (
    verification_level TEXT,
    verified_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ip.verification_level::TEXT,
        ip.verified_at,
        ip.expires_at
    FROM auth.identity_profiles ip
    WHERE ip.tenant_id = p_tenant_id
      AND ip.user_id = p_user_id
      AND ip.is_deleted = FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Get User Roles
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.get_user_roles(
    p_tenant_id UUID,
    p_user_id UUID
)
RETURNS TABLE (
    role_name TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT r.name::TEXT
    FROM auth.user_roles ur
    JOIN auth.roles r ON ur.role_id = r.id
    WHERE ur.tenant_id = p_tenant_id
      AND ur.user_id = p_user_id
      AND (ur.expires_at IS NULL OR ur.expires_at > NOW());
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Get User Capabilities (via Roles)
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.get_user_capabilities(
    p_tenant_id UUID,
    p_user_id UUID
)
RETURNS TABLE (
    capability_name TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT DISTINCT rc.capability_name::TEXT
    FROM auth.user_roles ur
    JOIN auth.role_capabilities rc ON ur.role_id = rc.role_id
    WHERE ur.tenant_id = p_tenant_id
      AND ur.user_id = p_user_id
      AND rc.tenant_id = p_tenant_id
      AND (ur.expires_at IS NULL OR ur.expires_at > NOW());
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Check if User Has Capability
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.user_has_capability(
    p_tenant_id UUID,
    p_user_id UUID,
    p_capability TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    v_has_capability BOOLEAN;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM auth.user_roles ur
        JOIN auth.role_capabilities rc ON ur.role_id = rc.role_id
        WHERE ur.tenant_id = p_tenant_id
          AND ur.user_id = p_user_id
          AND rc.tenant_id = p_tenant_id
          AND rc.capability_name = p_capability
          AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
    ) INTO v_has_capability;
    
    RETURN v_has_capability;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Assign Capability to Role
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.assign_capability_to_role(
    p_tenant_id UUID,
    p_role TEXT,
    p_capability TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    v_role_id UUID;
BEGIN
    -- Get role ID
    SELECT id INTO v_role_id
    FROM auth.roles
    WHERE tenant_id = p_tenant_id
      AND name = p_role;
    
    IF v_role_id IS NULL THEN
        RAISE EXCEPTION 'Role % not found in tenant %', p_role, p_tenant_id;
    END IF;
    
    -- Insert capability assignment (ignore if already exists)
    INSERT INTO auth.role_capabilities (tenant_id, role_id, capability_name)
    VALUES (p_tenant_id, v_role_id, p_capability)
    ON CONFLICT (tenant_id, role_id, capability_name) DO NOTHING;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Revoke Capability from Role
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.revoke_capability_from_role(
    p_tenant_id UUID,
    p_role TEXT,
    p_capability TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    v_role_id UUID;
    v_deleted_rows INTEGER;
BEGIN
    -- Get role ID
    SELECT id INTO v_role_id
    FROM auth.roles
    WHERE tenant_id = p_tenant_id
      AND name = p_role;
    
    IF v_role_id IS NULL THEN
        RAISE EXCEPTION 'Role % not found in tenant %', p_role, p_tenant_id;
    END IF;
    
    -- Delete capability assignment
    DELETE FROM auth.role_capabilities
    WHERE tenant_id = p_tenant_id
      AND role_id = v_role_id
      AND capability_name = p_capability;
    
    GET DIAGNOSTICS v_deleted_rows = ROW_COUNT;
    RETURN v_deleted_rows > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Assign Role to User
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.assign_role_to_user(
    p_tenant_id UUID,
    p_user_id UUID,
    p_role TEXT,
    p_assigned_by UUID DEFAULT NULL,
    p_expires_at TIMESTAMPTZ DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    v_role_id UUID;
    v_user_role_id UUID;
BEGIN
    -- Get role ID
    SELECT id INTO v_role_id
    FROM auth.roles
    WHERE tenant_id = p_tenant_id
      AND name = p_role;
    
    IF v_role_id IS NULL THEN
        RAISE EXCEPTION 'Role % not found in tenant %', p_role, p_tenant_id;
    END IF;
    
    -- Insert user-role assignment
    INSERT INTO auth.user_roles (tenant_id, user_id, role_id, assigned_by, expires_at)
    VALUES (p_tenant_id, p_user_id, v_role_id, p_assigned_by, p_expires_at)
    ON CONFLICT (tenant_id, user_id, role_id) DO UPDATE
    SET expires_at = EXCLUDED.expires_at
    RETURNING id INTO v_user_role_id;
    
    RETURN v_user_role_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- Revoke Role from User
-- -------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION auth.revoke_role_from_user(
    p_tenant_id UUID,
    p_user_id UUID,
    p_role TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    v_role_id UUID;
    v_deleted_rows INTEGER;
BEGIN
    -- Get role ID
    SELECT id INTO v_role_id
    FROM auth.roles
    WHERE tenant_id = p_tenant_id
      AND name = p_role;
    
    IF v_role_id IS NULL THEN
        RAISE EXCEPTION 'Role % not found in tenant %', p_role, p_tenant_id;
    END IF;
    
    -- Delete user-role assignment
    DELETE FROM auth.user_roles
    WHERE tenant_id = p_tenant_id
      AND user_id = p_user_id
      AND role_id = v_role_id;
    
    GET DIAGNOSTICS v_deleted_rows = ROW_COUNT;
    RETURN v_deleted_rows > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =========================================================================
-- SEED DATA - System Roles & Capabilities
-- =========================================================================

-- -------------------------------------------------------------------------
-- Seed System Capabilities
-- -------------------------------------------------------------------------
INSERT INTO auth.capabilities (name, description, category, is_system_capability) VALUES
-- Clone capabilities
('clone.create', 'Create new clones', 'clone', TRUE),
('clone.private_chat', 'Chat with private clones', 'clone', TRUE),
('clone.public_visibility', 'Make clones publicly visible', 'clone', TRUE),
('clone.visitor_chat', 'Allow visitors to chat with public clones', 'clone', TRUE),
('clone.multiple', 'Create multiple clones', 'clone', TRUE),
('clone.delete', 'Delete own clones', 'clone', TRUE),

-- Social capabilities
('social.post', 'Create social posts', 'social', TRUE),
('social.comment', 'Comment on posts', 'social', TRUE),
('social.message', 'Send direct messages', 'social', TRUE),
('social.group', 'Create/join groups', 'social', TRUE),

-- Family capabilities
('family.invitations', 'Invite family members', 'family', TRUE),
('family.access', 'Access family clone features', 'family', TRUE),

-- Monetization capabilities
('monetization.enable', 'Enable monetization features', 'monetization', TRUE),
('monetization.expertise_sessions', 'Offer paid expertise sessions', 'monetization', TRUE),
('monetization.payouts', 'Receive revenue payouts', 'monetization', TRUE),
('monetization.pricing', 'Set custom pricing', 'monetization', TRUE),

-- IoT capabilities
('iot.device_control', 'Control IoT devices', 'iot', TRUE),
('iot.automation', 'Create IoT automations', 'iot', TRUE),
('iot.device_add', 'Add new IoT devices', 'iot', TRUE),

-- Legacy capabilities
('legacy.posthumous_access', 'Configure posthumous access', 'legacy', TRUE),
('legacy.estate_planning', 'Estate planning features', 'legacy', TRUE),

-- Marketplace capabilities
('marketplace.list_clone', 'List clones in marketplace', 'marketplace', TRUE),
('marketplace.purchase', 'Purchase clone templates', 'marketplace', TRUE),

-- Admin capabilities
('admin.users.manage', 'Manage tenant users', 'admin', TRUE),
('admin.users.suspend', 'Suspend/ban users', 'admin', TRUE),
('admin.moderation', 'Content moderation', 'admin', TRUE),
('admin.analytics', 'View tenant analytics', 'admin', TRUE),

-- SuperAdmin capabilities
('superadmin.tenants.manage', 'Manage all tenants', 'superadmin', TRUE),
('superadmin.system.config', 'System configuration', 'superadmin', TRUE),
('superadmin.billing.override', 'Override billing rules', 'superadmin', TRUE)

ON CONFLICT (name) DO NOTHING;

-- -------------------------------------------------------------------------
-- Create System Roles for Each Tenant (Run after tenant creation)
-- -------------------------------------------------------------------------
-- This would be called from tenant provisioning logic
CREATE OR REPLACE FUNCTION auth.initialize_tenant_roles(p_tenant_id UUID)
RETURNS VOID AS $$
DECLARE
    v_user_role_id UUID;
    v_admin_role_id UUID;
    v_superadmin_role_id UUID;
BEGIN
    -- Create User role
    INSERT INTO auth.roles (tenant_id, name, description, is_system_role)
    VALUES (p_tenant_id, 'User', 'Standard user role', TRUE)
    RETURNING id INTO v_user_role_id;
    
    -- Assign basic capabilities to User role
    INSERT INTO auth.role_capabilities (tenant_id, role_id, capability_name) VALUES
    (p_tenant_id, v_user_role_id, 'clone.create'),
    (p_tenant_id, v_user_role_id, 'clone.private_chat'),
    (p_tenant_id, v_user_role_id, 'clone.delete'),
    (p_tenant_id, v_user_role_id, 'social.message');
    
    -- Create Admin role
    INSERT INTO auth.roles (tenant_id, name, description, is_system_role)
    VALUES (p_tenant_id, 'Admin', 'Tenant administrator role', TRUE)
    RETURNING id INTO v_admin_role_id;
    
    -- Assign admin capabilities
    INSERT INTO auth.role_capabilities (tenant_id, role_id, capability_name) VALUES
    (p_tenant_id, v_admin_role_id, 'admin.users.manage'),
    (p_tenant_id, v_admin_role_id, 'admin.users.suspend'),
    (p_tenant_id, v_admin_role_id, 'admin.moderation'),
    (p_tenant_id, v_admin_role_id, 'admin.analytics');
    
    -- Create SuperAdmin role (only for platform tenant)
    IF EXISTS (SELECT 1 FROM auth.tenants WHERE id = p_tenant_id AND is_platform_tenant = TRUE) THEN
        INSERT INTO auth.roles (tenant_id, name, description, is_system_role)
        VALUES (p_tenant_id, 'SuperAdmin', 'Platform super administrator', TRUE)
        RETURNING id INTO v_superadmin_role_id;
        
        -- Assign superadmin capabilities
        INSERT INTO auth.role_capabilities (tenant_id, role_id, capability_name) VALUES
        (p_tenant_id, v_superadmin_role_id, 'superadmin.tenants.manage'),
        (p_tenant_id, v_superadmin_role_id, 'superadmin.system.config'),
        (p_tenant_id, v_superadmin_role_id, 'superadmin.billing.override');
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =========================================================================
-- TRIGGERS
-- =========================================================================

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION auth.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_roles_updated_at
    BEFORE UPDATE ON auth.roles
    FOR EACH ROW
    EXECUTE FUNCTION auth.update_updated_at_column();

-- =========================================================================
-- ROW-LEVEL SECURITY
-- =========================================================================

ALTER TABLE auth.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE auth.role_capabilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE auth.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_isolation_roles ON auth.roles
    USING (tenant_id = current_setting('app.current_tenant', TRUE)::UUID);

CREATE POLICY tenant_isolation_role_capabilities ON auth.role_capabilities
    USING (tenant_id = current_setting('app.current_tenant', TRUE)::UUID);

CREATE POLICY tenant_isolation_user_roles ON auth.user_roles
    USING (tenant_id = current_setting('app.current_tenant', TRUE)::UUID);

-- =========================================================================
-- GRANTS
-- =========================================================================

GRANT USAGE ON SCHEMA auth TO keiroogenesis_api;
GRANT SELECT, INSERT, UPDATE, DELETE ON auth.roles TO keiroogenesis_api;
GRANT SELECT, INSERT, UPDATE, DELETE ON auth.role_capabilities TO keiroogenesis_api;
GRANT SELECT, INSERT, UPDATE, DELETE ON auth.user_roles TO keiroogenesis_api;
GRANT SELECT ON auth.capabilities TO keiroogenesis_api;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA auth TO keiroogenesis_api;

-- =========================================================================
-- COMMENTS
-- =========================================================================

COMMENT ON SCHEMA auth IS 'Authentication, identity verification, authorization, and RBAC';
COMMENT ON TABLE auth.roles IS 'User roles (e.g., User, Admin, SuperAdmin)';
COMMENT ON TABLE auth.capabilities IS 'System-wide capabilities/permissions';
COMMENT ON TABLE auth.role_capabilities IS 'Maps capabilities to roles (RBAC)';
COMMENT ON TABLE auth.user_roles IS 'Assigns roles to users';

-- =========================================================================
-- USAGE EXAMPLES
-- =========================================================================

/*
-- Initialize roles for a new tenant
SELECT auth.initialize_tenant_roles('tenant-uuid');

-- Assign User role to a new user
SELECT auth.assign_role_to_user('tenant-uuid', 'user-uuid', 'User');

-- Check if user has a capability
SELECT auth.user_has_capability('tenant-uuid', 'user-uuid', 'clone.create');

-- Get all user capabilities
SELECT * FROM auth.get_user_capabilities('tenant-uuid', 'user-uuid');

-- Assign custom capability to Admin role
SELECT auth.assign_capability_to_role('tenant-uuid', 'Admin', 'custom.capability');

-- Revoke capability from role
SELECT auth.revoke_capability_from_role('tenant-uuid', 'Admin', 'custom.capability');
*/

-- =========================================================================
-- END OF SCHEMA
-- =========================================================================
