// ==========================================================================
// CLONE WIZARD MODULE — 6-Step Clone Creation
// FINAL VERSION WITH OWNERSHIP GUARDS
// Single file: Repository + Service + Controller
// ==========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Dapper;
using KeiroGenesis.API.Core.Database;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

// ==========================================================================
#region Repository
// ==========================================================================
namespace KeiroGenesis.API.Repositories
{
    public class CloneWizardRepository
    {
        private readonly IDbConnectionFactory _db;
        private readonly ILogger<CloneWizardRepository> _logger;

        public CloneWizardRepository(IDbConnectionFactory db, ILogger<CloneWizardRepository> logger)
        {
            _db = db;
            _logger = logger;
        }

        // 🔐 OWNERSHIP VALIDATION (CANONICAL GUARD)
        public async Task<bool> CloneBelongsToUserAsync(
            Guid tenantId, Guid userId, Guid cloneId)
        {
            using var conn = _db.CreateConnection();

            bool exists = await conn.ExecuteScalarAsync<bool>(
                @"SELECT EXISTS (
                    SELECT 1
                    FROM clone.clones
                    WHERE clone_id = @clone_id
                      AND tenant_id = @tenant_id
                      AND user_id = @user_id
                      AND deleted_at IS NULL
                )",
                new { clone_id = cloneId, tenant_id = tenantId, user_id = userId }
            );

            return exists;
        }

        // Step 1: Create draft clone
        public async Task<dynamic?> CreateCloneDraftAsync(
            Guid tenantId, Guid userId, string displayName, 
            string tagline, string bio, string visibility)
        {
            using var conn = _db.CreateConnection();

            IEnumerable<dynamic> result = await conn.QueryAsync(
                "SELECT * FROM clone.fn_create_clone_draft(@tenant_id, @user_id, @display_name, @tagline, @bio, @visibility)",
                new
                {
                    tenant_id = tenantId,
                    user_id = userId,
                    display_name = displayName,
                    tagline = tagline,
                    bio = bio,
                    visibility = visibility
                }
            );

            return result.FirstOrDefault();
        }

        // Step 2: Update avatar
        public async Task<bool> UpdateCloneAvatarAsync(
            Guid tenantId, Guid cloneId, string avatarUrl)
        {
            using var conn = _db.CreateConnection();

            bool result = await conn.ExecuteScalarAsync<bool>(
                "SELECT clone.fn_update_clone_avatar(@tenant_id, @clone_id, @avatar_url)",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId,
                    avatar_url = avatarUrl
                }
            );

            return result;
        }

        // Step 3: Save personality
        public async Task<bool> SaveClonePersonalityAsync(
            Guid tenantId, Guid cloneId, string tone, string verbosity,
            string humor, string values, bool storytelling)
        {
            using var conn = _db.CreateConnection();

            bool result = await conn.ExecuteScalarAsync<bool>(
                @"SELECT clone.fn_save_clone_personality(
                    @tenant_id, @clone_id, @tone, @verbosity, @humor, @values, @storytelling
                )",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId,
                    tone = tone,
                    verbosity = verbosity,
                    humor = humor,
                    values = values,
                    storytelling = storytelling
                }
            );

            return result;
        }

        // Step 4: Add memory seeds
        public async Task<int> AddMemorySeedsAsync(
            Guid tenantId, Guid cloneId, string[] memories)
        {
            using var conn = _db.CreateConnection();

            int count = await conn.ExecuteScalarAsync<int>(
                "SELECT clone.fn_add_memory_seeds(@tenant_id, @clone_id, @memories)",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId,
                    memories = memories
                }
            );

            return count;
        }

        // Step 5: Upload knowledge documents
        public async Task<int> UploadKnowledgeDocumentsAsync(
            Guid tenantId, Guid cloneId, string documentsJson)
        {
            using var conn = _db.CreateConnection();

            int count = await conn.ExecuteScalarAsync<int>(
                "SELECT clone.fn_upload_knowledge_documents(@tenant_id, @clone_id, @documents::jsonb)",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId,
                    documents = documentsJson
                }
            );

            return count;
        }

        // Step 6: Activate clone
        public async Task<dynamic?> ActivateCloneAsync(
            Guid tenantId, Guid cloneId)
        {
            using var conn = _db.CreateConnection();

            IEnumerable<dynamic> result = await conn.QueryAsync(
                "SELECT * FROM clone.fn_activate_clone(@tenant_id, @clone_id)",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId
                }
            );

            return result.FirstOrDefault();
        }

        // Helper: Get wizard status
        public async Task<dynamic?> GetWizardStatusAsync(
            Guid tenantId, Guid cloneId)
        {
            using var conn = _db.CreateConnection();

            IEnumerable<dynamic> result = await conn.QueryAsync(
                "SELECT * FROM clone.fn_get_clone_wizard_status(@tenant_id, @clone_id)",
                new
                {
                    tenant_id = tenantId,
                    clone_id = cloneId
                }
            );

            return result.FirstOrDefault();
        }
    }
}
#endregion

// ==========================================================================
#region Service
// ==========================================================================
namespace KeiroGenesis.API.Services
{
    public class CloneWizardService
    {
        private readonly Repositories.CloneWizardRepository _repo;
        private readonly ILogger<CloneWizardService> _logger;

        public CloneWizardService(
            Repositories.CloneWizardRepository repo,
            ILogger<CloneWizardService> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        // Step 1: Create draft clone (no ownership check needed - creating new)
        public async Task<WizardResponse> CreateCloneDraftAsync(
            Guid tenantId, Guid userId, Step1Request request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.DisplayName))
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Display name is required",
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                dynamic? result = await _repo.CreateCloneDraftAsync(
                    tenantId, userId,
                    request.DisplayName,
                    request.Tagline ?? "",
                    request.Bio ?? "",
                    request.Visibility ?? "private"
                );

                if (result == null)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to create clone",
                        ErrorCode = "CREATION_FAILED"
                    };
                }

                if (result.status == "error")
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = result.error_message,
                        ErrorCode = "BUSINESS_RULE_VIOLATION"
                    };
                }

                _logger.LogInformation("Clone draft created: {CloneId} for user {UserId}", 
                    result.clone_id, userId);

                return new WizardResponse
                {
                    Success = true,
                    Message = "Clone draft created successfully",
                    Data = new
                    {
                        cloneId = result.clone_id,
                        cloneSlug = result.clone_slug,
                        status = result.status
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating clone draft for user {UserId}", userId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to create clone: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Step 2: Update avatar
        public async Task<WizardResponse> UpdateAvatarAsync(
            Guid tenantId, Guid userId, Guid cloneId, Step2Request request)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                if (string.IsNullOrWhiteSpace(request.AvatarUrl))
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Avatar URL is required",
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                bool success = await _repo.UpdateCloneAvatarAsync(
                    tenantId, cloneId, request.AvatarUrl
                );

                if (!success)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to update avatar",
                        ErrorCode = "UPDATE_FAILED"
                    };
                }

                _logger.LogInformation("Avatar updated for clone {CloneId}", cloneId);

                return new WizardResponse
                {
                    Success = true,
                    Message = "Avatar updated successfully"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating avatar for clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to update avatar: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Step 3: Save personality
        public async Task<WizardResponse> SavePersonalityAsync(
            Guid tenantId, Guid userId, Guid cloneId, Step3Request request)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                if (string.IsNullOrWhiteSpace(request.Tone))
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Tone is required",
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                string valuesJson = System.Text.Json.JsonSerializer.Serialize(request.Values ?? new string[0]);

                bool success = await _repo.SaveClonePersonalityAsync(
                    tenantId, cloneId,
                    request.Tone,
                    request.Verbosity ?? "medium",
                    request.Humor ?? "light",
                    valuesJson,
                    request.Storytelling
                );

                if (!success)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to save personality",
                        ErrorCode = "UPDATE_FAILED"
                    };
                }

                _logger.LogInformation("Personality saved for clone {CloneId}", cloneId);

                return new WizardResponse
                {
                    Success = true,
                    Message = "Personality saved successfully"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving personality for clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to save personality: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Step 4: Add memory seeds
        public async Task<WizardResponse> AddMemoriesAsync(
            Guid tenantId, Guid userId, Guid cloneId, Step4Request request)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                if (request.Memories == null || request.Memories.Length == 0)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "At least one memory is required",
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                int count = await _repo.AddMemorySeedsAsync(
                    tenantId, cloneId, request.Memories
                );

                if (count == 0)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to add memories",
                        ErrorCode = "UPDATE_FAILED"
                    };
                }

                _logger.LogInformation("Added {Count} memories for clone {CloneId}", count, cloneId);

                return new WizardResponse
                {
                    Success = true,
                    Message = $"{count} memories added successfully",
                    Data = new { memoriesAdded = count }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding memories for clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to add memories: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Step 5: Upload knowledge documents (metadata only)
        public async Task<WizardResponse> UploadKnowledgeAsync(
            Guid tenantId, Guid userId, Guid cloneId, Step5Request request)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                if (request.Documents == null || request.Documents.Length == 0)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "At least one document is required",
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                string documentsJson = System.Text.Json.JsonSerializer.Serialize(request.Documents);

                int count = await _repo.UploadKnowledgeDocumentsAsync(
                    tenantId, cloneId, documentsJson
                );

                if (count == 0)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to upload knowledge",
                        ErrorCode = "UPDATE_FAILED"
                    };
                }

                _logger.LogInformation("Queued {Count} documents for clone {CloneId}", count, cloneId);

                return new WizardResponse
                {
                    Success = true,
                    Message = $"{count} documents queued for processing",
                    Data = new
                    {
                        queued = true,
                        documentCount = count
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading knowledge for clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to upload knowledge: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Step 6: Activate clone
        public async Task<WizardResponse> ActivateCloneAsync(
            Guid tenantId, Guid userId, Guid cloneId)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                dynamic? result = await _repo.ActivateCloneAsync(tenantId, cloneId);

                if (result == null)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Failed to activate clone",
                        ErrorCode = "ACTIVATION_FAILED"
                    };
                }

                if (result.status == "error")
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = result.message,
                        ErrorCode = "VALIDATION_ERROR"
                    };
                }

                _logger.LogInformation("Clone activated: {CloneId}", cloneId);

                return new WizardResponse
                {
                    Success = true,
                    Message = result.message,
                    Data = new
                    {
                        cloneId = cloneId,
                        status = result.status,
                        activatedAt = result.activated_at
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error activating clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to activate clone: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }

        // Get wizard status
        public async Task<WizardResponse> GetWizardStatusAsync(
            Guid tenantId, Guid userId, Guid cloneId)
        {
            try
            {
                // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
                if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
                {
                    _logger.LogWarning(
                        "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                        userId, cloneId);

                    return new WizardResponse
                    {
                        Success = false,
                        Message = "You do not have access to this clone",
                        ErrorCode = "UNAUTHORIZED"
                    };
                }

                dynamic? status = await _repo.GetWizardStatusAsync(tenantId, cloneId);

                if (status == null)
                {
                    return new WizardResponse
                    {
                        Success = false,
                        Message = "Clone not found",
                        ErrorCode = "NOT_FOUND"
                    };
                }

                return new WizardResponse
                {
                    Success = true,
                    Data = new
                    {
                        cloneId = status.clone_id,
                        displayName = status.display_name,
                        cloneSlug = status.clone_slug,
                        status = status.status,
                        progress = new
                        {
                            step1_identity = true,
                            step2_avatar = status.has_avatar,
                            step3_personality = status.has_personality,
                            step4_memories = status.memory_count > 0,
                            step5_knowledge = status.document_count > 0,
                            canActivate = status.can_activate
                        },
                        counts = new
                        {
                            memories = status.memory_count,
                            documents = status.document_count
                        }
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting wizard status for clone {CloneId}", cloneId);
                return new WizardResponse
                {
                    Success = false,
                    Message = $"Failed to get status: {ex.Message}",
                    ErrorCode = "INTERNAL_ERROR"
                };
            }
        }
    }

    // Request/Response Models
    public class Step1Request
    {
        public string DisplayName { get; set; } = string.Empty;
        public string? Tagline { get; set; }
        public string? Bio { get; set; }
        public string? Visibility { get; set; }
    }

    public class Step2Request
    {
        public string AvatarUrl { get; set; } = string.Empty;
    }

    public class Step3Request
    {
        public string Tone { get; set; } = string.Empty;
        public string? Verbosity { get; set; }
        public string? Humor { get; set; }
        public string[]? Values { get; set; }
        public bool Storytelling { get; set; }
    }

    public class Step4Request
    {
        public string[] Memories { get; set; } = Array.Empty<string>();
    }

    public class Step5Request
    {
        public DocumentInfo[] Documents { get; set; } = Array.Empty<DocumentInfo>();
    }

    public class DocumentInfo
    {
        public string Title { get; set; } = string.Empty;
        public string Filename { get; set; } = string.Empty;
        public long FileSize { get; set; }
        public string MimeType { get; set; } = string.Empty;
    }

    public class WizardResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
        public string? ErrorCode { get; set; }
        public object? Data { get; set; }
    }
}
#endregion

// ==========================================================================
#region Controller
// ==========================================================================
namespace KeiroGenesis.API.Controllers.V1
{
    [Route("api/v1/[controller]")]
    [Authorize]
    public class CloneWizardController : ControllerBase
    {
        private readonly Services.CloneWizardService _service;
        private readonly ILogger<CloneWizardController> _logger;

        public CloneWizardController(
            Services.CloneWizardService service,
            ILogger<CloneWizardController> logger)
        {
            _service = service;
            _logger = logger;
        }

        private Guid GetTenantId()
        {
            string? claim = User.FindFirst("tenant_id")?.Value;
            if (claim == null || !Guid.TryParse(claim, out Guid tenantId))
                throw new UnauthorizedAccessException("Invalid tenant claim");
            return tenantId;
        }

        private Guid GetCurrentUserId()
        {
            string? claim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                         ?? User.FindFirst("sub")?.Value;
            if (claim == null || !Guid.TryParse(claim, out Guid userId))
                throw new UnauthorizedAccessException("Invalid user claim");
            return userId;
        }

        /// <summary>
        /// Create draft clone (Step 1)
        /// </summary>
        [HttpPost]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        public async Task<IActionResult> Create([FromBody] Services.Step1Request request)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Creating clone for user {UserId}", userId);

            Services.WizardResponse result = await _service.CreateCloneDraftAsync(tenantId, userId, request);

            if (!result.Success)
                return BadRequest(result);

            return Ok(result);
        }

        /// <summary>
        /// Update avatar (Step 2)
        /// </summary>
        [HttpPut("{cloneId}/avatar")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> UpdateAvatar(Guid cloneId, [FromBody] Services.Step2Request request)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Updating avatar for clone {CloneId}", cloneId);

            Services.WizardResponse result = await _service.UpdateAvatarAsync(tenantId, userId, cloneId, request);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return BadRequest(result);
            }

            return Ok(result);
        }

        /// <summary>
        /// Configure personality (Step 3)
        /// </summary>
        [HttpPut("{cloneId}/personality")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> SavePersonality(Guid cloneId, [FromBody] Services.Step3Request request)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Saving personality for clone {CloneId}", cloneId);

            Services.WizardResponse result = await _service.SavePersonalityAsync(tenantId, userId, cloneId, request);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return BadRequest(result);
            }

            return Ok(result);
        }

        /// <summary>
        /// Add memory seeds (Step 4)
        /// </summary>
        [HttpPost("{cloneId}/memories")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> AddMemories(Guid cloneId, [FromBody] Services.Step4Request request)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Adding memories for clone {CloneId}", cloneId);

            Services.WizardResponse result = await _service.AddMemoriesAsync(tenantId, userId, cloneId, request);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return BadRequest(result);
            }

            return Ok(result);
        }

        /// <summary>
        /// Upload knowledge documents (Step 5 - metadata only)
        /// </summary>
        [HttpPost("{cloneId}/knowledge")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> UploadKnowledge(Guid cloneId, [FromBody] Services.Step5Request request)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Uploading knowledge for clone {CloneId}", cloneId);

            Services.WizardResponse result = await _service.UploadKnowledgeAsync(tenantId, userId, cloneId, request);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return BadRequest(result);
            }

            return Ok(result);
        }

        /// <summary>
        /// Activate clone (Step 6)
        /// </summary>
        [HttpPost("{cloneId}/activate")]
        [ProducesResponseType(200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(403)]
        public async Task<IActionResult> Activate(Guid cloneId)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            _logger.LogInformation("Activating clone {CloneId}", cloneId);

            Services.WizardResponse result = await _service.ActivateCloneAsync(tenantId, userId, cloneId);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return BadRequest(result);
            }

            return Ok(result);
        }

        /// <summary>
        /// Get wizard status (resume wizard)
        /// </summary>
        [HttpGet("{cloneId}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> GetStatus(Guid cloneId)
        {
            Guid tenantId = GetTenantId();
            Guid userId = GetCurrentUserId();

            Services.WizardResponse result = await _service.GetWizardStatusAsync(tenantId, userId, cloneId);

            if (!result.Success)
            {
                if (result.ErrorCode == "UNAUTHORIZED")
                    return StatusCode(403, result);
                return NotFound(result);
            }

            return Ok(result);
        }
    }
}
#endregion
