-- ==========================================================================
-- CLONE WIZARD FUNCTIONS - SIMPLIFIED VERSION
-- Ownership validation happens in C# layer
-- Functions focus on business logic only
-- ==========================================================================

-- ============================================
-- STEP 1: CREATE DRAFT CLONE
-- (Unchanged - needs user_id for creation)
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_create_clone_draft(
    p_tenant_id uuid,
    p_user_id uuid,
    p_display_name varchar(100),
    p_tagline varchar(255),
    p_bio varchar(2000),
    p_visibility varchar(20)
)
RETURNS TABLE(
    clone_id uuid,
    clone_slug varchar(100),
    status varchar(20),
    error_message text
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_clone_id uuid;
    v_clone_slug varchar(100);
    v_clone_count int;
BEGIN
    -- MVP: Check 1 clone per user limit
    SELECT COUNT(*) INTO v_clone_count
    FROM clone.clones
    WHERE user_id = p_user_id
      AND tenant_id = p_tenant_id
      AND deleted_at IS NULL;
    
    IF v_clone_count >= 1 THEN
        RETURN QUERY SELECT 
            NULL::uuid,
            NULL::varchar(100),
            'error'::varchar(20),
            'User already has a clone (MVP limit: 1 per user)'::text;
        RETURN;
    END IF;
    
    v_clone_id := gen_random_uuid();
    v_clone_slug := LOWER(REPLACE(REPLACE(p_display_name, ' ', '_'), '''', ''));
    
    WHILE EXISTS (SELECT 1 FROM clone.clones WHERE clone_slug = v_clone_slug) LOOP
        v_clone_slug := v_clone_slug || '_' || SUBSTRING(MD5(RANDOM()::text), 1, 4);
    END LOOP;
    
    INSERT INTO clone.clones (
        clone_id, tenant_id, user_id,
        display_name, clone_slug, tagline, bio, visibility,
        status, is_active, created_at, updated_at
    )
    VALUES (
        v_clone_id, p_tenant_id, p_user_id,
        p_display_name, v_clone_slug, COALESCE(p_tagline, ''), COALESCE(p_bio, ''),
        COALESCE(p_visibility, 'private'), 'draft', true, NOW(), NOW()
    );
    
    RETURN QUERY SELECT 
        v_clone_id, v_clone_slug, 'draft'::varchar(20), NULL::text;
END;
$$;

-- ============================================
-- STEP 2: UPDATE AVATAR (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_update_clone_avatar(
    p_tenant_id uuid,
    p_clone_id uuid,
    p_avatar_url varchar(500)
)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
    v_rows_affected int;
BEGIN
    UPDATE clone.clones
    SET 
        avatar_url = p_avatar_url,
        updated_at = NOW()
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id
      AND deleted_at IS NULL;
    
    GET DIAGNOSTICS v_rows_affected = ROW_COUNT;
    RETURN v_rows_affected > 0;
END;
$$;

-- ============================================
-- STEP 3: SAVE PERSONALITY (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_save_clone_personality(
    p_tenant_id uuid,
    p_clone_id uuid,
    p_tone varchar(50),
    p_verbosity varchar(50),
    p_humor varchar(50),
    p_values text,
    p_storytelling boolean
)
RETURNS boolean
LANGUAGE plpgsql
AS $$
DECLARE
    v_system_prompt text;
BEGIN
    -- Delete existing personality traits
    DELETE FROM clone.personality_templates
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id;
    
    -- Insert new personality traits
    INSERT INTO clone.personality_templates (template_id, clone_id, tenant_id, trait_key, question_text, answer_text, created_at)
    VALUES 
        (gen_random_uuid(), p_clone_id, p_tenant_id, 'tone', 'What is your communication style?', p_tone, NOW()),
        (gen_random_uuid(), p_clone_id, p_tenant_id, 'verbosity', 'How detailed are your responses?', p_verbosity, NOW()),
        (gen_random_uuid(), p_clone_id, p_tenant_id, 'humor', 'What is your humor level?', p_humor, NOW()),
        (gen_random_uuid(), p_clone_id, p_tenant_id, 'values', 'What are your core values?', p_values, NOW()),
        (gen_random_uuid(), p_clone_id, p_tenant_id, 'storytelling', 'Do you use storytelling?', p_storytelling::text, NOW());
    
    -- Generate system prompt
    v_system_prompt := 'You are a digital clone with the following characteristics: ' ||
                       'Communication style is ' || p_tone || '. ' ||
                       'Response length is ' || p_verbosity || '. ' ||
                       'Humor level is ' || p_humor || '. ' ||
                       'Core values: ' || p_values || '. ' ||
                       CASE WHEN p_storytelling THEN 'Uses storytelling in responses.' ELSE 'Direct and factual.' END;
    
    -- Update clone
    UPDATE clone.clones
    SET 
        system_prompt = v_system_prompt,
        voice_style = p_tone,
        updated_at = NOW()
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id;
    
    RETURN true;
END;
$$;

-- ============================================
-- STEP 4: ADD MEMORY SEEDS (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_add_memory_seeds(
    p_tenant_id uuid,
    p_clone_id uuid,
    p_memories text[]
)
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
    v_memory text;
    v_memory_id uuid;
    v_count int := 0;
    v_clone_actor_id uuid;
BEGIN
    v_clone_actor_id := p_clone_id;
    
    FOREACH v_memory IN ARRAY p_memories
    LOOP
        v_memory_id := gen_random_uuid();
        
        INSERT INTO memory.memories (
            memory_id, clone_id, tenant_id,
            title, content, memory_type, processing_status,
            created_at
        )
        VALUES (
            v_memory_id, p_clone_id, p_tenant_id,
            'Seed Memory', v_memory, 'seed', 'pending',
            NOW()
        );
        
        INSERT INTO rag.embedding_queue (
            queue_id, tenant_id, actor_id, source_id, source_type,
            status, priority, created_at
        )
        VALUES (
            gen_random_uuid(), p_tenant_id, v_clone_actor_id, v_memory_id, 'memory',
            'pending', 5, NOW()
        );
        
        v_count := v_count + 1;
    END LOOP;
    
    RETURN v_count;
END;
$$;

-- ============================================
-- STEP 5: UPLOAD KNOWLEDGE DOCUMENTS (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_upload_knowledge_documents(
    p_tenant_id uuid,
    p_clone_id uuid,
    p_documents jsonb
)
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
    v_doc jsonb;
    v_document_id uuid;
    v_count int := 0;
    v_clone_actor_id uuid;
BEGIN
    v_clone_actor_id := p_clone_id;
    
    FOR v_doc IN SELECT * FROM jsonb_array_elements(p_documents)
    LOOP
        v_document_id := gen_random_uuid();
        
        INSERT INTO rag.documents (
            document_id, tenant_id, owner_actor_id, source_id, source_type,
            title, description, processing_status, metadata, created_at
        )
        VALUES (
            v_document_id, p_tenant_id, v_clone_actor_id, p_clone_id, 'clone_knowledge',
            v_doc->>'title', 'Knowledge document for clone', 'pending', v_doc, NOW()
        );
        
        INSERT INTO rag.embedding_queue (
            queue_id, tenant_id, actor_id, source_id, source_type,
            status, priority, created_at
        )
        VALUES (
            gen_random_uuid(), p_tenant_id, v_clone_actor_id, v_document_id, 'document',
            'pending', 5, NOW()
        );
        
        v_count := v_count + 1;
    END LOOP;
    
    RETURN v_count;
END;
$$;

-- ============================================
-- STEP 6: ACTIVATE CLONE (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_activate_clone(
    p_tenant_id uuid,
    p_clone_id uuid
)
RETURNS TABLE(
    status varchar(20),
    message text,
    activated_at timestamptz
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_clone_record RECORD;
    v_personality_count int;
    v_memory_count int;
    v_activated_at timestamptz;
BEGIN
    -- Get clone
    SELECT * INTO v_clone_record
    FROM clone.clones
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id
      AND deleted_at IS NULL;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT 
            'error'::varchar(20),
            'Clone not found'::text,
            NULL::timestamptz;
        RETURN;
    END IF;
    
    -- Validate wizard completion
    IF v_clone_record.display_name IS NULL OR v_clone_record.display_name = '' THEN
        RETURN QUERY SELECT 
            'error'::varchar(20),
            'Display name is required'::text,
            NULL::timestamptz;
        RETURN;
    END IF;
    
    SELECT COUNT(*) INTO v_personality_count
    FROM clone.personality_templates
    WHERE clone_id = p_clone_id;
    
    IF v_personality_count = 0 THEN
        RETURN QUERY SELECT 
            'error'::varchar(20),
            'Personality configuration is required'::text,
            NULL::timestamptz;
        RETURN;
    END IF;
    
    SELECT COUNT(*) INTO v_memory_count
    FROM memory.memories
    WHERE clone_id = p_clone_id;
    
    IF v_memory_count = 0 THEN
        RETURN QUERY SELECT 
            'error'::varchar(20),
            'At least one memory is required'::text,
            NULL::timestamptz;
        RETURN;
    END IF;
    
    -- Activate clone
    v_activated_at := NOW();
    
    UPDATE clone.clones
    SET 
        status = 'active',
        is_active = true,
        updated_at = v_activated_at
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id;
    
    RETURN QUERY SELECT 
        'active'::varchar(20),
        'Clone activated successfully'::text,
        v_activated_at;
END;
$$;

-- ============================================
-- HELPER: GET WIZARD STATUS (SIMPLIFIED)
-- Ownership already verified in C#
-- ============================================
CREATE OR REPLACE FUNCTION clone.fn_get_clone_wizard_status(
    p_tenant_id uuid,
    p_clone_id uuid
)
RETURNS TABLE(
    clone_id uuid,
    display_name varchar(100),
    clone_slug varchar(100),
    status varchar(20),
    has_avatar boolean,
    has_personality boolean,
    memory_count int,
    document_count int,
    can_activate boolean
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_clone RECORD;
    v_personality_count int;
    v_memory_count int;
    v_document_count int;
    v_has_avatar boolean;
    v_can_activate boolean;
BEGIN
    -- Get clone
    SELECT * INTO v_clone
    FROM clone.clones c
    WHERE c.clone_id = p_clone_id
      AND c.tenant_id = p_tenant_id
      AND c.deleted_at IS NULL;
    
    IF NOT FOUND THEN
        RETURN;
    END IF;
    
    v_has_avatar := v_clone.avatar_url IS NOT NULL AND v_clone.avatar_url != '';
    
    SELECT COUNT(*) INTO v_personality_count
    FROM clone.personality_templates
    WHERE clone.personality_templates.clone_id = p_clone_id;
    
    SELECT COUNT(*) INTO v_memory_count
    FROM memory.memories
    WHERE memory.memories.clone_id = p_clone_id;
    
    SELECT COUNT(*) INTO v_document_count
    FROM rag.documents
    WHERE source_id = p_clone_id
      AND source_type = 'clone_knowledge';
    
    v_can_activate := (
        v_clone.display_name IS NOT NULL AND 
        v_clone.display_name != '' AND
        v_personality_count > 0 AND
        v_memory_count > 0
    );
    
    RETURN QUERY SELECT 
        v_clone.clone_id,
        v_clone.display_name,
        v_clone.clone_slug,
        v_clone.status,
        v_has_avatar,
        (v_personality_count > 0) as has_personality,
        v_memory_count,
        v_document_count,
        v_can_activate;
END;
$$;

-- ============================================
-- GRANT PERMISSIONS
-- ============================================
GRANT EXECUTE ON FUNCTION clone.fn_create_clone_draft(uuid, uuid, varchar, varchar, varchar, varchar) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_update_clone_avatar(uuid, uuid, varchar) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_save_clone_personality(uuid, uuid, varchar, varchar, varchar, text, boolean) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_add_memory_seeds(uuid, uuid, text[]) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_upload_knowledge_documents(uuid, uuid, jsonb) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_activate_clone(uuid, uuid) TO kg_app_user;
GRANT EXECUTE ON FUNCTION clone.fn_get_clone_wizard_status(uuid, uuid) TO kg_app_user;

-- ============================================
-- VERIFICATION
-- ============================================
SELECT routine_name, routine_type
FROM information_schema.routines
WHERE routine_schema = 'clone'
  AND routine_name LIKE 'fn_%'
ORDER BY routine_name;
