using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Npgsql;
using System.Data;
using System.Security.Claims;

namespace KeiroGenesis.Authorization
{
    // =========================================================================
    // AUTHORIZATION SERVICE - ACCESS DECISIONS
    // Purpose: Answer "Can this user do X?"
    // Uses: Identity signals + Roles + Capabilities + Billing + Tenant Policy
    // =========================================================================
    
    // =========================================================================
    // CONTROLLER - Authorization Endpoints
    // =========================================================================
    
    [ApiController]
    [Route("api/v1/authorization")]
    [Produces("application/json")]
    public class AuthorizationController : ControllerBase
    {
        private readonly AuthorizationService _service;
        private readonly ILogger<AuthorizationController> _logger;

        public AuthorizationController(
            AuthorizationService service,
            ILogger<AuthorizationController> logger)
        {
            _service = service;
            _logger = logger;
        }

        private Guid GetTenantId() => Guid.Parse(User.FindFirst("tenant_id")?.Value 
            ?? throw new UnauthorizedAccessException("Tenant ID not found"));
        private Guid GetUserId() => Guid.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value 
            ?? throw new UnauthorizedAccessException("User ID not found"));

        /// <summary>
        /// Checks if user has access to a specific capability.
        /// Makes decision based on: Identity + Role + Billing + Tenant Policy.
        /// </summary>
        [HttpPost("check-access")]
        [Authorize]
        public async Task<ActionResult<AccessDecisionResponse>> CheckAccess([FromBody] AccessCheckRequest request)
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.CheckAccessAsync(tenantId, userId, request.Capability);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking access");
                return StatusCode(500, new { message = "Failed to check access" });
            }
        }

        /// <summary>
        /// Gets all capabilities available to the current user.
        /// </summary>
        [HttpGet("my-capabilities")]
        [Authorize]
        public async Task<ActionResult<List<string>>> GetMyCapabilities()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.GetUserCapabilitiesAsync(tenantId, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting capabilities");
                return StatusCode(500, new { message = "Failed to retrieve capabilities" });
            }
        }

        /// <summary>
        /// Gets user's current authorization context (roles, tier, identity level).
        /// </summary>
        [HttpGet("context")]
        [Authorize]
        public async Task<ActionResult<AuthorizationContextResponse>> GetContext()
        {
            try
            {
                var tenantId = GetTenantId();
                var userId = GetUserId();
                var result = await _service.GetAuthorizationContextAsync(tenantId, userId);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting authorization context");
                return StatusCode(500, new { message = "Failed to retrieve authorization context" });
            }
        }
    }

    // =========================================================================
    // SERVICE - Authorization Business Logic
    // =========================================================================
    
    public class AuthorizationService
    {
        private readonly AuthorizationRepository _repository;
        private readonly ILogger<AuthorizationService> _logger;

        // Capability → Requirements mapping
        private readonly Dictionary<string, CapabilityRequirements> _capabilityRequirements = new()
        {
            // Basic capabilities (available to all)
            { "clone.create", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.Unverified, MinTier = SubscriptionTier.Free } },
            { "clone.private_chat", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.Unverified, MinTier = SubscriptionTier.Free } },
            
            // Public visibility (requires age assurance)
            { "clone.public_visibility", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.AgeAssured, MinTier = SubscriptionTier.Free } },
            { "clone.visitor_chat", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.AgeAssured, MinTier = SubscriptionTier.Free } },
            { "social.post", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.AgeAssured, MinTier = SubscriptionTier.Free } },
            { "social.comment", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.AgeAssured, MinTier = SubscriptionTier.Free } },
            
            // Family features (requires human verification)
            { "family.invitations", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.HumanVerified, MinTier = SubscriptionTier.Starter } },
            { "clone.multiple", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.HumanVerified, MinTier = SubscriptionTier.Starter } },
            
            // Monetization (requires government ID + subscription)
            { "monetization.enable", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            { "monetization.expertise_sessions", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            { "monetization.payouts", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            
            // IoT control (requires government ID + subscription)
            { "iot.device_control", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            { "iot.automation", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            
            // Legacy features (requires government ID)
            { "legacy.posthumous_access", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            { "legacy.estate_planning", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Professional } },
            
            // Marketplace (requires government ID + enterprise)
            { "marketplace.list_clone", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Enterprise } },
            { "marketplace.purchase", new CapabilityRequirements { MinIdentityLevel = IdentityVerificationLevel.GovernmentVerified, MinTier = SubscriptionTier.Enterprise } },
            
            // Admin capabilities
            { "admin.users.manage", new CapabilityRequirements { RequiresRole = "Admin" } },
            { "admin.moderation", new CapabilityRequirements { RequiresRole = "Admin" } },
            { "admin.analytics", new CapabilityRequirements { RequiresRole = "Admin" } },
            { "superadmin.tenants.manage", new CapabilityRequirements { RequiresRole = "SuperAdmin" } },
            { "superadmin.system.config", new CapabilityRequirements { RequiresRole = "SuperAdmin" } }
        };

        public AuthorizationService(
            AuthorizationRepository repository,
            ILogger<AuthorizationService> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        /// <summary>
        /// Makes access decision based on ALL factors:
        /// - Identity verification level (SIGNAL)
        /// - User roles
        /// - Capabilities assigned to roles
        /// - Subscription tier
        /// - Tenant policies
        /// </summary>
        public async Task<AccessDecisionResponse> CheckAccessAsync(
            Guid tenantId,
            Guid userId,
            string capability)
        {
            // Get all context
            var context = await GetAuthorizationContextAsync(tenantId, userId);
            
            // Get capability requirements
            if (!_capabilityRequirements.TryGetValue(capability, out var requirements))
            {
                return new AccessDecisionResponse
                {
                    Capability = capability,
                    Allowed = false,
                    Reason = "Unknown capability",
                    DenialReasons = new List<string> { "Capability not defined in system" }
                };
            }

            var denialReasons = new List<string>();

            // Check role requirement
            if (!string.IsNullOrEmpty(requirements.RequiresRole))
            {
                if (!context.Roles.Contains(requirements.RequiresRole))
                {
                    denialReasons.Add($"Requires {requirements.RequiresRole} role");
                }
            }

            // Check identity verification level
            if (context.IdentityLevel < requirements.MinIdentityLevel)
            {
                denialReasons.Add($"Requires {requirements.MinIdentityLevel} identity verification (current: {context.IdentityLevel})");
            }

            // Check subscription tier
            if (context.SubscriptionTier < requirements.MinTier)
            {
                denialReasons.Add($"Requires {requirements.MinTier} subscription (current: {context.SubscriptionTier})");
            }

            // Check if user has capability explicitly assigned
            var hasCapabilityViaRole = await _repository.UserHasCapabilityAsync(tenantId, userId, capability);

            var allowed = denialReasons.Count == 0 || hasCapabilityViaRole;

            _logger.LogInformation(
                "Access check for user {UserId} capability {Capability}: {Result}",
                userId, capability, allowed ? "ALLOWED" : "DENIED");

            return new AccessDecisionResponse
            {
                Capability = capability,
                Allowed = allowed,
                Reason = allowed ? "Access granted" : "Access denied",
                DenialReasons = denialReasons.Any() ? denialReasons : null,
                RequiredIdentityLevel = requirements.MinIdentityLevel,
                CurrentIdentityLevel = context.IdentityLevel,
                RequiredTier = requirements.MinTier,
                CurrentTier = context.SubscriptionTier
            };
        }

        /// <summary>
        /// Gets all capabilities available to user based on their roles.
        /// </summary>
        public async Task<List<string>> GetUserCapabilitiesAsync(Guid tenantId, Guid userId)
        {
            var capabilities = await _repository.GetUserCapabilitiesAsync(tenantId, userId);
            
            _logger.LogInformation(
                "User {UserId} has {Count} capabilities via roles",
                userId, capabilities.Count);

            return capabilities;
        }

        /// <summary>
        /// Gets complete authorization context for user.
        /// Combines: Identity signals + Roles + Billing + Tenant info.
        /// </summary>
        public async Task<AuthorizationContextResponse> GetAuthorizationContextAsync(
            Guid tenantId,
            Guid userId)
        {
            // Get identity verification status (SIGNAL from Identity module)
            var identityStatus = await _repository.GetIdentityVerificationLevelAsync(tenantId, userId);
            
            // Get user roles
            var roles = await _repository.GetUserRolesAsync(tenantId, userId);
            
            // Get subscription tier (from billing)
            var subscriptionTier = await _repository.GetSubscriptionTierAsync(tenantId);
            
            // Get capabilities via roles
            var capabilities = await _repository.GetUserCapabilitiesAsync(tenantId, userId);

            return new AuthorizationContextResponse
            {
                UserId = userId,
                TenantId = tenantId,
                IdentityLevel = identityStatus.Level,
                IdentityVerifiedAt = identityStatus.VerifiedAt,
                IdentityExpired = identityStatus.IsExpired,
                Roles = roles,
                SubscriptionTier = subscriptionTier,
                Capabilities = capabilities
            };
        }

        /// <summary>
        /// Assigns a capability to a role.
        /// </summary>
        public async Task<bool> AssignCapabilityToRoleAsync(
            Guid tenantId,
            string role,
            string capability)
        {
            var result = await _repository.AssignCapabilityToRoleAsync(tenantId, role, capability);
            
            _logger.LogInformation(
                "Capability {Capability} assigned to role {Role} in tenant {TenantId}",
                capability, role, tenantId);

            return result;
        }

        /// <summary>
        /// Removes a capability from a role.
        /// </summary>
        public async Task<bool> RevokeCapabilityFromRoleAsync(
            Guid tenantId,
            string role,
            string capability)
        {
            var result = await _repository.RevokeCapabilityFromRoleAsync(tenantId, role, capability);
            
            _logger.LogInformation(
                "Capability {Capability} revoked from role {Role} in tenant {TenantId}",
                capability, role, tenantId);

            return result;
        }
    }

    // =========================================================================
    // REPOSITORY - Database Access Layer
    // =========================================================================
    
    public class AuthorizationRepository
    {
        private readonly string _connectionString;

        public AuthorizationRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("KeiroGenesisDb") 
                ?? throw new ArgumentNullException("Database connection string not found");
        }

        private IDbConnection CreateConnection() => new NpgsqlConnection(_connectionString);

        /// <summary>
        /// Gets identity verification level for user (SIGNAL from Identity module).
        /// </summary>
        public async Task<(IdentityVerificationLevel Level, DateTime? VerifiedAt, bool IsExpired)> 
            GetIdentityVerificationLevelAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryFirstOrDefaultAsync<dynamic>(
                "auth.get_identity_verification_level",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);

            if (result == null)
            {
                return (IdentityVerificationLevel.Unverified, null, false);
            }

            var level = Enum.Parse<IdentityVerificationLevel>(result.verification_level.ToString());
            var verifiedAt = result.verified_at as DateTime?;
            var expiresAt = result.expires_at as DateTime?;
            var isExpired = expiresAt.HasValue && expiresAt.Value < DateTime.UtcNow;

            return (level, verifiedAt, isExpired);
        }

        /// <summary>
        /// Gets all roles assigned to user.
        /// </summary>
        public async Task<List<string>> GetUserRolesAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryAsync<string>(
                "auth.get_user_roles",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);
            return result.ToList();
        }

        /// <summary>
        /// Gets subscription tier for tenant (from billing).
        /// </summary>
        public async Task<SubscriptionTier> GetSubscriptionTierAsync(Guid tenantId)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryFirstOrDefaultAsync<string>(
                "billing.get_subscription_tier",
                new { p_tenant_id = tenantId },
                commandType: CommandType.StoredProcedure);

            return Enum.TryParse<SubscriptionTier>(result, out var tier) 
                ? tier 
                : SubscriptionTier.Free;
        }

        /// <summary>
        /// Gets all capabilities available to user via their roles.
        /// </summary>
        public async Task<List<string>> GetUserCapabilitiesAsync(Guid tenantId, Guid userId)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryAsync<string>(
                "auth.get_user_capabilities",
                new { p_tenant_id = tenantId, p_user_id = userId },
                commandType: CommandType.StoredProcedure);
            return result.ToList();
        }

        /// <summary>
        /// Checks if user has a specific capability.
        /// </summary>
        public async Task<bool> UserHasCapabilityAsync(Guid tenantId, Guid userId, string capability)
        {
            using var connection = CreateConnection();
            var result = await connection.QueryFirstOrDefaultAsync<bool>(
                "auth.user_has_capability",
                new { p_tenant_id = tenantId, p_user_id = userId, p_capability = capability },
                commandType: CommandType.StoredProcedure);
            return result;
        }

        /// <summary>
        /// Assigns a capability to a role.
        /// </summary>
        public async Task<bool> AssignCapabilityToRoleAsync(Guid tenantId, string role, string capability)
        {
            using var connection = CreateConnection();
            var result = await connection.ExecuteAsync(
                "auth.assign_capability_to_role",
                new { p_tenant_id = tenantId, p_role = role, p_capability = capability },
                commandType: CommandType.StoredProcedure);
            return result > 0;
        }

        /// <summary>
        /// Revokes a capability from a role.
        /// </summary>
        public async Task<bool> RevokeCapabilityFromRoleAsync(Guid tenantId, string role, string capability)
        {
            using var connection = CreateConnection();
            var result = await connection.ExecuteAsync(
                "auth.revoke_capability_from_role",
                new { p_tenant_id = tenantId, p_role = role, p_capability = capability },
                commandType: CommandType.StoredProcedure);
            return result > 0;
        }
    }
}

// =========================================================================
// DTOs
// =========================================================================

namespace KeiroGenesis.Authorization.DTOs
{
    public class AccessCheckRequest
    {
        public string Capability { get; set; } = string.Empty;
    }

    public class AccessDecisionResponse
    {
        public string Capability { get; set; } = string.Empty;
        public bool Allowed { get; set; }
        public string Reason { get; set; } = string.Empty;
        public List<string>? DenialReasons { get; set; }
        public IdentityVerificationLevel? RequiredIdentityLevel { get; set; }
        public IdentityVerificationLevel? CurrentIdentityLevel { get; set; }
        public SubscriptionTier? RequiredTier { get; set; }
        public SubscriptionTier? CurrentTier { get; set; }
    }

    public class AuthorizationContextResponse
    {
        public Guid UserId { get; set; }
        public Guid TenantId { get; set; }
        public IdentityVerificationLevel IdentityLevel { get; set; }
        public DateTime? IdentityVerifiedAt { get; set; }
        public bool IdentityExpired { get; set; }
        public List<string> Roles { get; set; } = new();
        public SubscriptionTier SubscriptionTier { get; set; }
        public List<string> Capabilities { get; set; } = new();
    }
}

// =========================================================================
// MODELS
// =========================================================================

namespace KeiroGenesis.Authorization.Models
{
    public class CapabilityRequirements
    {
        public IdentityVerificationLevel MinIdentityLevel { get; set; } = IdentityVerificationLevel.Unverified;
        public SubscriptionTier MinTier { get; set; } = SubscriptionTier.Free;
        public string? RequiresRole { get; set; }
    }
}

// =========================================================================
// ENUMS
// =========================================================================

namespace KeiroGenesis.Authorization
{
    public enum IdentityVerificationLevel
    {
        Unverified = 0,
        AgeAssured = 1,
        HumanVerified = 2,
        GovernmentVerified = 3
    }

    public enum SubscriptionTier
    {
        Free = 0,
        Starter = 1,
        Professional = 2,
        Enterprise = 3
    }
}
