# CLONE WIZARD - FINAL ARCHITECTURE
## Defense-in-Depth Security Pattern

---

## 🔐 **CANONICAL AUTHORIZATION PATTERN**

### **The Rule:**
> Every endpoint that mutates a clone must verify `(tenantId + userId + cloneId)` ownership in C# BEFORE calling the database.

---

## 📊 **SECURITY LAYERS**

```
1. Authentication (JWT)          → Who are you?
2. Authorization (Ownership)     → Do you own this clone?  ← NEW GUARD
3. Database (Business Logic)     → Execute the operation
```

---

## 🔒 **OWNERSHIP GUARD (Required for Steps 2-6)**

### **Repository Helper:**

```csharp
public async Task<bool> CloneBelongsToUserAsync(
    Guid tenantId, Guid userId, Guid cloneId)
{
    using var conn = _db.CreateConnection();

    bool exists = await conn.ExecuteScalarAsync<bool>(
        @"SELECT EXISTS (
            SELECT 1
            FROM clone.clones
            WHERE clone_id = @clone_id
              AND tenant_id = @tenant_id
              AND user_id = @user_id
              AND deleted_at IS NULL
        )",
        new { clone_id = cloneId, tenant_id = tenantId, user_id = userId }
    );

    return exists;
}
```

### **Service Guard (MANDATORY):**

```csharp
// Step 2: Update avatar
public async Task<WizardResponse> UpdateAvatarAsync(
    Guid tenantId, Guid userId, Guid cloneId, Step2Request request)
{
    try
    {
        // 🔐 OWNERSHIP CHECK (MANDATORY GUARD)
        if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
        {
            _logger.LogWarning(
                "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
                userId, cloneId);

            return new WizardResponse
            {
                Success = false,
                Message = "You do not have access to this clone",
                ErrorCode = "UNAUTHORIZED"
            };
        }

        // NOW proceed with mutation
        bool success = await _repo.UpdateCloneAvatarAsync(
            tenantId, cloneId, request.AvatarUrl
        );
        
        // ...
    }
}
```

---

## ✅ **WHERE THE GUARD APPLIES**

| Step | Endpoint | Ownership Check | Reason |
|------|----------|----------------|--------|
| **Step 1** | `POST /clonewizard` | ❌ No | Creating NEW clone |
| **Step 2** | `PUT /{id}/avatar` | ✅ YES | Mutating EXISTING clone |
| **Step 3** | `PUT /{id}/personality` | ✅ YES | Mutating EXISTING clone |
| **Step 4** | `POST /{id}/memories` | ✅ YES | Mutating EXISTING clone |
| **Step 5** | `POST /{id}/knowledge` | ✅ YES | Mutating EXISTING clone |
| **Step 6** | `POST /{id}/activate` | ✅ YES | Mutating EXISTING clone |
| **Status** | `GET /{id}` | ✅ YES | Reading EXISTING clone |

---

## 🎯 **DATABASE FUNCTIONS (SIMPLIFIED)**

Since ownership is verified in C#, database functions focus on **business logic only**:

### **Before (Complex - Wrong):**
```sql
-- Function had to verify ownership
CREATE FUNCTION fn_update_clone_avatar(
    p_tenant_id uuid,
    p_user_id uuid,      -- Extra complexity
    p_clone_id uuid,
    p_avatar_url varchar
)
BEGIN
    -- Verify ownership in DB
    SELECT EXISTS(...) INTO v_authorized;
    IF NOT v_authorized THEN
        RETURN false;
    END IF;
    
    -- Then update
    UPDATE clone.clones SET avatar_url = ...
END;
```

### **After (Simple - Correct):**
```sql
-- Function just does the work
CREATE FUNCTION fn_update_clone_avatar(
    p_tenant_id uuid,
    p_clone_id uuid,     -- No user_id needed
    p_avatar_url varchar
)
BEGIN
    -- Just update (ownership already verified)
    UPDATE clone.clones 
    SET avatar_url = p_avatar_url
    WHERE clone_id = p_clone_id
      AND tenant_id = p_tenant_id
      AND deleted_at IS NULL;
END;
```

**Why simpler?**
- Authorization already happened in C#
- Function focuses on business logic
- Single responsibility principle
- Easier to test and maintain

---

## 🔄 **COMPLETE FLOW (Step 2 Example)**

### **1. Frontend Request:**
```javascript
PUT /api/v1/clonewizard/{cloneId}/avatar
Authorization: Bearer {jwt}
Body: { "avatarUrl": "https://..." }
```

### **2. Controller (Extract Claims):**
```csharp
[HttpPut("{cloneId}/avatar")]
public async Task<IActionResult> UpdateAvatar(Guid cloneId, ...)
{
    Guid tenantId = GetTenantId();    // From JWT
    Guid userId = GetCurrentUserId();  // From JWT
    
    var result = await _service.UpdateAvatarAsync(
        tenantId, userId, cloneId, request
    );
}
```

### **3. Service (Guard + Validate + Execute):**
```csharp
public async Task<WizardResponse> UpdateAvatarAsync(...)
{
    // 🔐 STEP 1: OWNERSHIP CHECK
    if (!await _repo.CloneBelongsToUserAsync(tenantId, userId, cloneId))
    {
        _logger.LogWarning("Unauthorized access...");
        return new WizardResponse { 
            Success = false, 
            ErrorCode = "UNAUTHORIZED" 
        };
    }
    
    // STEP 2: VALIDATION
    if (string.IsNullOrWhiteSpace(request.AvatarUrl))
    {
        return new WizardResponse { 
            Success = false, 
            ErrorCode = "VALIDATION_ERROR" 
        };
    }
    
    // STEP 3: EXECUTE
    bool success = await _repo.UpdateCloneAvatarAsync(...);
}
```

### **4. Repository (Call DB Function):**
```csharp
public async Task<bool> UpdateCloneAvatarAsync(...)
{
    using var conn = _db.CreateConnection();
    
    return await conn.ExecuteScalarAsync<bool>(
        "SELECT clone.fn_update_clone_avatar(@tenant_id, @clone_id, @avatar_url)",
        new { tenant_id, clone_id, avatar_url }
    );
}
```

### **5. Database (Business Logic Only):**
```sql
UPDATE clone.clones 
SET avatar_url = p_avatar_url, updated_at = NOW()
WHERE clone_id = p_clone_id
  AND tenant_id = p_tenant_id
  AND deleted_at IS NULL;
```

---

## 🛡️ **SECURITY BENEFITS**

### **Defense in Depth:**
1. **JWT Validation** - Ensures authenticated user
2. **Ownership Check** - Ensures authorized user
3. **Tenant Isolation** - Ensures data segregation
4. **Soft Delete Check** - Prevents zombie data access

### **Attack Surface Reduction:**
```
❌ Without Guard:
   Any authenticated user in tenant → Modify ANY clone

✅ With Guard:
   Authenticated user → Own clone only
```

### **Audit Trail:**
```csharp
_logger.LogWarning(
    "Unauthorized clone access attempt. User {UserId}, Clone {CloneId}",
    userId, cloneId
);
```

Every unauthorized attempt is logged for security monitoring.

---

## 📋 **IMPLEMENTATION CHECKLIST**

### **Repository:**
- ✅ Add `CloneBelongsToUserAsync` helper
- ✅ Remove `userId` param from mutation functions
- ✅ Keep simple SQL queries

### **Service:**
- ✅ Call ownership guard FIRST in every mutation method
- ✅ Log warning on unauthorized attempts
- ✅ Return `UNAUTHORIZED` error code
- ✅ Only proceed if ownership verified

### **Controller:**
- ✅ Extract `userId` and `tenantId` from JWT
- ✅ Pass both to service methods
- ✅ Return `403 Forbidden` on `UNAUTHORIZED` error

### **Database:**
- ✅ Simplified functions (no user_id in mutations)
- ✅ Focus on business logic only
- ✅ Trust C# layer for authorization

---

## 🎯 **ERROR CODES**

| Code | HTTP | Meaning | When |
|------|------|---------|------|
| `UNAUTHORIZED` | 403 | Clone doesn't belong to user | Ownership check fails |
| `VALIDATION_ERROR` | 400 | Invalid input | Required field missing |
| `NOT_FOUND` | 404 | Clone doesn't exist | Clone deleted or never existed |
| `UPDATE_FAILED` | 400 | Database mutation failed | Unexpected DB error |
| `INTERNAL_ERROR` | 500 | Unhandled exception | Try/catch in service |

---

## ✅ **FINAL ARCHITECTURE**

```
┌─────────────────────────────────────────────────────────┐
│                      FRONTEND                           │
│  PUT /api/v1/clonewizard/{id}/avatar                   │
│  Authorization: Bearer {JWT}                            │
└──────────────────┬──────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│                     CONTROLLER                          │
│  • Extract tenantId from JWT                           │
│  • Extract userId from JWT                             │
│  • Call Service                                         │
└──────────────────┬──────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│                      SERVICE                            │
│  🔐 GUARD: CloneBelongsToUserAsync()                   │
│  ✅ If authorized → Proceed                            │
│  ❌ If unauthorized → Return 403                       │
└──────────────────┬──────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│                    REPOSITORY                           │
│  • Call PostgreSQL function                            │
│  • Return result                                        │
└──────────────────┬──────────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────────┐
│                     DATABASE                            │
│  • Execute business logic                              │
│  • Return success/failure                               │
└─────────────────────────────────────────────────────────┘
```

---

## 🎉 **PRODUCTION READY**

**This architecture implements:**
- ✅ Defense in depth
- ✅ Separation of concerns
- ✅ Single responsibility principle
- ✅ Secure by default
- ✅ Auditable access attempts
- ✅ Clean code patterns
- ✅ Testable components

**Ready for production deployment.**
